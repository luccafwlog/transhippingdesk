# HANDOFF — Alinhar o app Transhipping Desk ao Design System

> **Para o agente de código (Claude Code / similar).** Este pacote é o **design
> system canônico** da Transhipping Desk — a *fonte da verdade* para cores,
> tipografia, espaçamento, componentes e telas. Ele foi derivado diretamente do
> próprio código do produto (`src/index.css` e `src/components/*`), então não é um
> design novo: é o estado **pretendido**. Sua tarefa é **auditar o app real e
> corrigir as divergências** (drift) para que ele volte a bater com este sistema.

## Capturas de referência (estado pretendido)

Em `handoff-screenshots/` estão as telas renderizadas a partir deste design system
— use-as como alvo visual ("como deve ficar"):

- `01-login.png` — Acesso interno (painel de marca navy + formulário).
- `02-painel.png` — Painel: faixa de mercado, header, nav com gold rule, Line Up.
- `03-painel-kpis.png` — KPIs do Painel (valores inteiros, sem quebra).
- `04-faturamento.png` — Faturamento: tiles `R$ 243.180,00` etc. em uma linha.
- `05-faturamento-modal.png` — Detalhe da fatura (modal) — note `TOTAL · R$ 8.420,00` inteiro.
- `06-portal-faturas.png` — Portal do cliente: tabs Taxas Locais / Demurrage.
- `07-portal-pix-modal.png` — Detalhe + pagamento PIX no portal.

## Como usar este pacote

1. Leia `readme.md` (guia geral), `SKILL.md` e os arquivos em `tokens/`.
2. Trate `styles.css` → `tokens/*.css` como a **definição oficial** dos tokens.
   No produto eles vivem em `src/index.css` sob `:root` / `:root[data-visual-theme='light']`.
3. Compare token a token com o app em produção e **reconcilie o app**, não o
   design system. Onde o app divergir, ajuste o app.
4. Use as telas em `ui_kits/` como referência visual de "como deve ficar"
   (Desk Operacional e Portal do Cliente).

## Regra: valores numéricos NUNCA quebram nem são cortados

O cliente identificou cards em que o valor (ex.: `R$ 8.420,00`) **quebrava em
várias linhas** dentro do card. Isso é proibido: **um valor monetário/numérico é
atômico** — deve aparecer inteiro, em uma única linha, sem omitir dígitos.

Regras canônicas (já aplicadas em `tokens/components.css`):
- `.app-metric-tile__value` e `.app-kpi-card__value` usam `white-space: nowrap`
  (+ `word-break: keep-all`) — o número nunca parte.
- **Nunca** use `overflow-wrap: anywhere` / `word-break: break-all` em elementos
  que contêm valores. (Foi exatamente a causa do bug.)
- Grades que contêm cards de valor usam
  `grid-template-columns: repeat(auto-fit, minmax(200px, 1fr))` — assim as colunas
  diminuem em **quantidade** (reflow) antes de ficarem estreitas demais para o número.
- O KPI usa `font-size: clamp(...)` para acompanhar a largura, mas o piso do clamp
  deve manter o maior valor esperado em uma linha.

**Checklist para o agente no app real:**
- [ ] Nenhum `.app-kpi-card__value` / `.app-metric-tile__value` quebra em 2+ linhas
      no maior valor plausível (ex.: `R$ 243.180,00`, `$ 1.240.000,00`).
- [ ] Nenhum valor é cortado/elipsado escondendo dígitos.
- [ ] Grades de KPIs fazem reflow (menos colunas) em telas estreitas, sem apertar.

## Divergência já identificada pelo cliente: TIPOGRAFIA

O cliente observou que **a fonte do app em produção está diferente** do desenho.
Os tokens canônicos de fonte são (de `tokens/typography.css`):

| Uso | Token | Família | Onde aplica |
|---|---|---|---|
| Títulos / display | `--app-font-display` | **Syne** (700/800, `letter-spacing: -0.04em`) | `.page-header__title`, `.app-modal__title`, `.app-header__eyebrow` |
| Texto / UI | `--app-font-body` | **DM Sans** (400–600) | `body`, controles, tabelas |
| Números / dinheiro | `--app-font-mono` | **IBM Plex Mono** | `.financial`, valores, KPIs |

As três famílias são carregadas via Google Fonts (mesmo `@import` do produto):
```
https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=Syne:wght@600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,600&display=swap
```

**Checklist para o agente investigar no app real:**
- [ ] O `@import` (ou `<link>`) das 3 fontes está presente e **carregando** (sem bloqueio de CSP/rede)?
- [ ] `--app-font-display`, `--app-font-body`, `--app-font-mono` estão definidos em `:root` exatamente como em `tokens/`?
- [ ] Os títulos (`.page-header__title` etc.) usam `var(--app-font-display)` (Syne) e **não** estão caindo no fallback `DM Sans`/sans-serif?
- [ ] Os pesos pedidos (Syne 700/800) estão disponíveis — senão a fonte renderiza num peso/forma diferente?
- [ ] Os valores numéricos usam `.financial` (IBM Plex Mono) e não a fonte de UI?

> Causa mais provável de "fonte diferente": o `@import` da Syne não está sendo
> carregado em produção (CSP, ordem de import, ou removido por engano), fazendo os
> títulos caírem no fallback. Garanta o carregamento e a aplicação do token.

## Demais tokens canônicos (resumo)

- **Cores:** navy `#152238` (estrutura), gold `#d4882e` (único acento), fundo papel
  `#f4f1ea` + dot grid, superfícies `#ffffff`. Sinais: azul `#1d4d88`, verde
  `#1a8c50`, âmbar `#d4882e`, vermelho `#c0393f` (cada um com variante "soft").
  Tema claro é o canônico; `data-visual-theme='dark'` é opt-in.
- **Forma:** raio padrão 8px (modais 16px, pills 999px); elevação quase plana —
  superfícies definidas por **bordas de 1,5px**, não sombras.
- **Espaçamento:** escala base 4px; altura de controle 44px.

Detalhe completo em `tokens/colors.css`, `tokens/spacing.css`, `tokens/components.css`.

## Regra de ouro

**O design system manda.** Se o app divergir, ajuste o app. Não altere os tokens
deste pacote para "bater" com o app atual — é o app que precisa convergir para cá.
