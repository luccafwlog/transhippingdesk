---
name: transhipping-design
description: Use this skill to generate well-branded interfaces and assets for Transhipping Desk (Transhipping · Agenciamento Marítimo), a Brazilian maritime-agency operations platform, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick orientation
- **Brand:** Transhipping · Agenciamento Marítimo — internal maritime operations **desk** + customer **portal**. Language is Brazilian Portuguese; the domain is dense, tabular and financial.
- **Entry point:** link `styles.css` (a manifest of `@import`s reaching `tokens/*`). Tokens are CSS custom properties (`--app-navy`, `--app-gold`, `--app-blue-btn`, `--app-text`, …). Light theme is canonical; `:root[data-visual-theme='dark']` is opt-in.
- **Components:** compiled into `_ds_bundle.js` under `window.TranshippingDeskDesignSystem_64fdac`. Mount in plain HTML via `<script src=".../_ds_bundle.js">` then `const { Button, Badge, Card, KpiCard, … } = window.TranshippingDeskDesignSystem_64fdac`. See each component's `.prompt.md`.
- **UI kits:** `ui_kits/operational-desk/` and `ui_kits/billing-portal/` are full interactive recreations — copy one as a starting point for a real screen.

## House rules
- Navy is structure; **one** gold accent only. Warm-paper background + dot grid; pure-white surfaces; near-flat (1.5px borders, not shadows).
- All numbers/money in IBM Plex Mono (`.financial`). Syne for display titles, DM Sans for everything else.
- Icons are **Lucide** at 1.5–2px stroke. No emoji, no hand-drawn SVG icons — copy `ui_kits/*/Icon.jsx` to render Lucide inline.
- Status badges carry fixed meaning: green=pago/pronto, blue=emitida/info, amber=revisão, red=vencida.
- Write copy in Brazilian Portuguese; uppercase for eyebrows/table headers/labels/badges.
