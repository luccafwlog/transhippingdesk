import React from 'react'

/**
 * The fundamental bordered surface — a 1.5px-bordered white panel with an 8px
 * radius and no shadow. Pass `padded={false}` for flush content like tables.
 */
export function Card({ padded = true, className = '', children, ...props }) {
  const classes = ['app-surface', padded ? 'app-surface--padded' : '', className]
    .filter(Boolean)
    .join(' ')
  return (
    <section className={classes} {...props}>
      {children}
    </section>
  )
}
