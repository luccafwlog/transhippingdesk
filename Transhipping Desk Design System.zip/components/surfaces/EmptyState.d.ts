import * as React from 'react'

/** Centered empty placeholder for tables and lists. */
export interface EmptyStateProps {
  /** Optional icon node (lucide glyph) shown in a bordered tile. */
  icon?: React.ReactNode
  /** Headline. */
  title: React.ReactNode
  /** Optional secondary line. */
  description?: React.ReactNode
}

export function EmptyState(props: EmptyStateProps): React.JSX.Element
