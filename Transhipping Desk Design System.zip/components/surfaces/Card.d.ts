import * as React from 'react'

/**
 * Fundamental bordered surface — a white panel, 1.5px border, 8px radius, no shadow.
 *
 * @startingPoint section="Surfaces" subtitle="Bordered content panel" viewport="700x200"
 */
export interface CardProps extends React.HTMLAttributes<HTMLElement> {
  /** Apply 22px internal padding. Set false for flush content like tables. @default true */
  padded?: boolean
}

export function Card(props: CardProps): React.JSX.Element
