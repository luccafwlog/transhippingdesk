import React from 'react'

/**
 * Centered placeholder shown when a table or list has no rows. A bordered icon
 * tile over a title and optional description.
 */
export function EmptyState({ icon, title, description }) {
  return (
    <div className="app-empty-state">
      {icon ? <div className="app-empty-state__icon">{icon}</div> : null}
      <p className="app-empty-state__title">{title}</p>
      {description ? <p className="app-empty-state__description">{description}</p> : null}
    </div>
  )
}
