import * as React from 'react'

/** Soft-red inline error band for form/data failures. */
export interface InlineErrorProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Optional leading icon (lucide AlertCircle). */
  icon?: React.ReactNode
  /** Error text (alternative to children). */
  message?: React.ReactNode
}

export function InlineError(props: InlineErrorProps): React.JSX.Element
