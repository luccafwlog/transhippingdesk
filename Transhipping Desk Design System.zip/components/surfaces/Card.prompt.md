One-line: The surface family — Card (bordered panel), PageHeader (gold-ruled title), EmptyState (no-rows placeholder), InlineError (form failure band).

```jsx
<PageHeader
  title="Faturas"
  description="Consulte suas faturas, pague via PIX e consolide B/Ls em aberto."
  action={<Button><FilePlus2 size={16} /> Gerar fatura consolidada</Button>}
/>

<Card>Conteúdo com padding.</Card>
<Card padded={false}><table className="app-table">…</table></Card>

<EmptyState icon={<Inbox size={34} strokeWidth={1.7} />} title="Nenhuma escala encontrada." description="Ajuste o filtro de status." />

<InlineError icon={<AlertCircle size={15} />} message="Erro ao carregar faturamento." />
```

`Card` is the only surface — flat, 1.5px border, no shadow; use `padded={false}` to wrap tables flush. `PageHeader` starts every screen; its title sits in Syne with an automatic 48px gold underline. Icons throughout are lucide-react.
