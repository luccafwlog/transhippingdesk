import React from 'react'

/**
 * The standard page title block: a Syne display heading with a 48px gold rule
 * beneath it, optional description, and a right-aligned action slot. Begins
 * every screen in the desk and portal.
 */
export function PageHeader({ title, description, action }) {
  return (
    <div className="page-header">
      <div className="page-header__copy">
        <h1 className="page-header__title">{title}</h1>
        {description ? <p className="page-header__description">{description}</p> : null}
      </div>
      {action ? <div className="page-header__actions">{action}</div> : null}
    </div>
  )
}
