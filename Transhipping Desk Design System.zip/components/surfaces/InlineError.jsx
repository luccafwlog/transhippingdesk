import React from 'react'

/**
 * Inline error band for form and data-load failures — soft red, bold, with a
 * leading alert icon slot.
 */
export function InlineError({ icon, message, children, className = '', ...props }) {
  const classes = ['app-inline-error', className].filter(Boolean).join(' ')
  return (
    <div className={classes} {...props}>
      {icon}
      {message ?? children}
    </div>
  )
}
