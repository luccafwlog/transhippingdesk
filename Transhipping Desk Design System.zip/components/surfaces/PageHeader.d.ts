import * as React from 'react'

/** Standard page title block with gold underline rule and action slot. */
export interface PageHeaderProps {
  /** Display title (Syne). */
  title: React.ReactNode
  /** Optional supporting description. */
  description?: React.ReactNode
  /** Right-aligned actions (buttons, status text). */
  action?: React.ReactNode
}

export function PageHeader(props: PageHeaderProps): React.JSX.Element
