One-line: Navigation controls — TabButton (pill or underline tabs) and FilterBar (collapsible filter panel with active-count badge).

```jsx
// Pill tabs (Painel line-up filter)
<TabButton active={tab==='all'} onClick={()=>setTab('all')}>Todas as escalas</TabButton>
<TabButton active={tab==='active'} onClick={()=>setTab('active')}>Escalas ativas</TabButton>

// Underline tabs (portal Taxas Locais / Demurrage) — sit inside a bottom-bordered row
<TabButton underline active label="Taxas Locais" />

// Collapsible filters
<FilterBar activeCount={2} onClear={reset}>
  <div className="app-filter-grid">
    <Field label="Status"><Select>…</Select></Field>
    <Field label="B/L"><Input placeholder="Número do B/L" /></Field>
  </div>
</FilterBar>
```

Pill tabs are the default; the underline idiom is for tab strips under a `border-b`. `FilterBar` hides its body until toggled and only shows Clear when filters are active.
