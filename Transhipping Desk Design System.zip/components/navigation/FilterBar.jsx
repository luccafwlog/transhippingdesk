import React from 'react'

/**
 * Collapsible filter bar — a toggle row showing the active-filter count and a
 * Clear button, expanding to reveal a grid of fields. Wrap filter `Field`s as
 * children.
 */
export function FilterBar({
  label = 'Filtros',
  activeCount = 0,
  defaultOpen = false,
  onClear,
  children,
}) {
  const [open, setOpen] = React.useState(defaultOpen)
  return (
    <div className={`app-filter-bar${open ? ' app-filter-bar--open' : ''}`}>
      <div className="app-filter-bar__head">
        <button type="button" className="app-filter-bar__toggle" onClick={() => setOpen((v) => !v)}>
          <span className="app-filter-bar__chevron" aria-hidden="true">
            {open ? '▾' : '▸'}
          </span>
          {label}
          {activeCount > 0 ? <span className="app-filter-bar__count">{activeCount}</span> : null}
        </button>
        {activeCount > 0 && onClear ? (
          <button type="button" className="app-btn app-btn--ghost app-btn--sm app-filter-bar__clear" onClick={onClear}>
            Limpar
          </button>
        ) : null}
      </div>
      {open ? <div className="app-filter-bar__body">{children}</div> : null}
    </div>
  )
}
