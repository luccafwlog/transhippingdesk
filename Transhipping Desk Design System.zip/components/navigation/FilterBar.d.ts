import * as React from 'react'

/** Collapsible filter bar with active-count badge and Clear action. */
export interface FilterBarProps {
  /** Toggle label. @default "Filtros" */
  label?: React.ReactNode
  /** Number of active filters; shown as a badge. @default 0 */
  activeCount?: number
  /** Start expanded. @default false */
  defaultOpen?: boolean
  /** Clear-all handler; the Clear button only shows when activeCount > 0. */
  onClear?: () => void
  /** Filter fields, typically inside a `.app-filter-grid`. */
  children: React.ReactNode
}

export function FilterBar(props: FilterBarProps): React.JSX.Element
