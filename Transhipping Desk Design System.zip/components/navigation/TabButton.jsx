import React from 'react'

/**
 * A single tab control. Two visual idioms exist in the product: standalone
 * pill tabs (default) and underline tabs (`underline`) used under a bottom
 * border. Toggle `active` for the selected state.
 */
export function TabButton({ active = false, underline = false, className = '', children, ...props }) {
  const classes = underline
    ? ['tab-underline', active ? 'tab-underline--active' : '', className]
    : ['app-tab', active ? 'app-tab--active' : '', className]
  return (
    <button type="button" className={classes.filter(Boolean).join(' ')} {...props}>
      {children}
    </button>
  )
}
