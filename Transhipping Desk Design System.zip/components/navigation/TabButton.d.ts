import * as React from 'react'

/**
 * Single tab control — pill (default) or underline idiom.
 *
 * @startingPoint section="Navigation" subtitle="Tabs & collapsible filter bar" viewport="700x180"
 */
export interface TabButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Selected state. @default false */
  active?: boolean
  /** Use the underline tab idiom (below a bottom border) instead of pills. @default false */
  underline?: boolean
}

export function TabButton(props: TabButtonProps): React.JSX.Element
