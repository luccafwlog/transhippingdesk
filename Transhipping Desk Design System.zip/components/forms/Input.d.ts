import * as React from 'react'

/** Text input with 44px height and blue focus ring. */
export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  /** Span the full width of the container. @default true */
  full?: boolean
}

export function Input(props: InputProps): React.JSX.Element
