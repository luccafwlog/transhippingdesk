import React from 'react'

/**
 * Multi-line text input. Vertically resizable, 112px minimum height.
 */
export function Textarea({ full = true, className = '', ...props }) {
  const classes = ['app-input', 'app-textarea', full ? 'app-input--full' : '', className]
    .filter(Boolean)
    .join(' ')
  return <textarea className={classes} {...props} />
}
