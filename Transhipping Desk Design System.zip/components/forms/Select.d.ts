import * as React from 'react'

/** Native select styled to match Input, with a custom caret. */
export interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  /** Span the full width of the container. @default true */
  full?: boolean
}

export function Select(props: SelectProps): React.JSX.Element
