import * as React from 'react'

/**
 * Labelled field wrapper for form controls.
 *
 * @startingPoint section="Forms" subtitle="Inputs, selects & fields" viewport="700x320"
 */
export interface FieldProps {
  /** Uppercase field label. */
  label?: React.ReactNode
  /** id of the control this labels. */
  htmlFor?: string
  /** Show a red required asterisk. @default false */
  required?: boolean
  /** Validation message shown below the control. */
  error?: React.ReactNode
  /** The control element (Input/Select/Textarea). */
  children: React.ReactNode
}

export function Field(props: FieldProps): React.JSX.Element
