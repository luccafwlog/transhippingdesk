import React from 'react'

/**
 * Labelled form field wrapper: an uppercase label over the control, with an
 * optional error line below. Wrap any Input/Select/Textarea.
 */
export function Field({ label, htmlFor, required = false, error, children }) {
  return (
    <div className="app-field">
      {label ? (
        <label className="app-field__label" htmlFor={htmlFor}>
          {label}
          {required ? <span className="app-field__required"> *</span> : null}
        </label>
      ) : null}
      {children}
      {error ? <div className="app-field__error">{error}</div> : null}
    </div>
  )
}
