import React from 'react'

/**
 * Native select styled to match Input, with a custom dual-chevron caret.
 */
export function Select({ full = true, className = '', children, ...props }) {
  const classes = ['app-input', 'app-select', full ? 'app-input--full' : '', className]
    .filter(Boolean)
    .join(' ')
  return (
    <select className={classes} {...props}>
      {children}
    </select>
  )
}
