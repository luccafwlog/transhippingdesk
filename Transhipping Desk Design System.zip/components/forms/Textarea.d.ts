import * as React from 'react'

/** Multi-line text input, vertically resizable. */
export interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  /** Span the full width of the container. @default true */
  full?: boolean
}

export function Textarea(props: TextareaProps): React.JSX.Element
