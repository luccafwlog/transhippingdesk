import React from 'react'

/**
 * Text input. Inherits the 44px control height, inset highlight, and blue
 * focus ring. Pass `full` to span its container.
 */
export function Input({ full = true, className = '', ...props }) {
  const classes = ['app-input', full ? 'app-input--full' : '', className].filter(Boolean).join(' ')
  return <input className={classes} {...props} />
}
