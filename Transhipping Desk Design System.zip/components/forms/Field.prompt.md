One-line: The form family — Field (labelled wrapper) plus Input, Select, and Textarea controls sharing one 44px control rhythm and blue focus ring.

```jsx
<Field label="Email" htmlFor="email" required>
  <Input id="email" type="email" placeholder="voce@empresa.com.br" />
</Field>

<Field label="POD">
  <Select>
    <option value="">Todos</option>
    <option>BRSSZ</option>
    <option>BRRIG</option>
  </Select>
</Field>

<Field label="Observações" error="Campo obrigatório">
  <Textarea placeholder="Notas internas…" />
</Field>
```

Controls span their container by default (`full`). Labels are uppercase, tracked, muted. The focus ring is a 4px soft-blue halo. Lay filter rows out in `.app-filter-grid` (auto-fit minmax 220px). Labels and placeholders are written in Portuguese.
