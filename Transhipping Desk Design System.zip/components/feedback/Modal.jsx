import React from 'react'

/**
 * Centered modal dialog with a navy header bar and a scrollable body. Backdrop
 * is a blurred dark scrim; click it or the × to dismiss. Renders nothing when
 * `open` is false.
 */
export function Modal({ open, onClose, title, width, children }) {
  if (!open) return null
  return (
    <div className="app-modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose && onClose()}>
      <div className="app-modal" style={width ? { width } : undefined} role="dialog" aria-modal="true">
        <div className="app-modal__header">
          <h2 className="app-modal__title">{title}</h2>
          <button type="button" className="app-btn app-btn--ghost app-modal__close" onClick={onClose} aria-label="Fechar">
            ✕
          </button>
        </div>
        <div className="app-modal__body">{children}</div>
      </div>
    </div>
  )
}
