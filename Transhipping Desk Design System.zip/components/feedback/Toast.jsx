import React from 'react'

const TONE_LABEL = { success: '✓', error: '!', info: 'i' }

/**
 * A single toast notification. Stack several inside a `.app-toast-stack`
 * fixed to the bottom-right. Three tones cover the product's feedback.
 */
export function Toast({ tone = 'info', children, onClose }) {
  return (
    <div className={`app-toast app-toast--${tone}`} role="status">
      <span className="app-toast__icon" aria-hidden="true">
        {TONE_LABEL[tone] || TONE_LABEL.info}
      </span>
      <span style={{ flex: 1 }}>{children}</span>
      {onClose ? (
        <button type="button" className="app-toast__close" onClick={onClose} aria-label="Fechar">
          ✕
        </button>
      ) : null}
    </div>
  )
}
