One-line: Feedback surfaces — Modal (navy-headed dialog over a blurred scrim) and Toast (corner notification in success/error/info tones).

```jsx
<Modal open={open} onClose={close} title="Fatura INV-2048">
  <div className="grid gap-5">…detalhe…</div>
</Modal>

// Toasts: render a stack fixed bottom-right
<div className="app-toast-stack">
  <Toast tone="success" onClose={dismiss}>Fatura consolidada desfeita. Os B/Ls foram liberados.</Toast>
  <Toast tone="error">Falha ao desfazer a fatura.</Toast>
</div>
```

`Modal` headers are navy with a Syne title and a ghost × button; the body scrolls if tall. Backdrop click dismisses. `Toast` tones: `success` (green), `error` (red), `info` (blue) — short, action-confirming Portuguese sentences.
