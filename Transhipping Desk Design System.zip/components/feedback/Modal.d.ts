import * as React from 'react'

/**
 * Centered modal dialog with navy header and scrollable body.
 *
 * @startingPoint section="Feedback" subtitle="Dialog & toast notifications" viewport="700x460"
 */
export interface ModalProps {
  /** Controls visibility. Renders nothing when false. */
  open: boolean
  /** Dismiss handler (× button and backdrop click). */
  onClose?: () => void
  /** Header title (Syne). */
  title?: React.ReactNode
  /** Optional explicit width, e.g. "1080px" or "min(100%, 720px)". */
  width?: string
  /** Dialog body content. */
  children: React.ReactNode
}

export function Modal(props: ModalProps): React.JSX.Element | null
