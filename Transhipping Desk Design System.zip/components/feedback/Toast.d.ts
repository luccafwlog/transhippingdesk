import * as React from 'react'

/** Single toast notification; stack inside `.app-toast-stack`. */
export interface ToastProps {
  /** Semantic tone. @default "info" */
  tone?: 'success' | 'error' | 'info'
  /** Optional dismiss handler (shows × button). */
  onClose?: () => void
  /** Message content. */
  children: React.ReactNode
}

export function Toast(props: ToastProps): React.JSX.Element
