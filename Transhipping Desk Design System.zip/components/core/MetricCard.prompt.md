One-line: Labelled metric tiles (MetricCard) and advisory callouts (Callout) — the small information primitives.

```jsx
<MetricCard label="Saldo pendente" value={formatBRL(12450)} />
<MetricCard label="Faturas emitidas" value="18" />

<Callout variant="warning">Configure VITE_SUPABASE_URL no .env antes de autenticar.</Callout>
```

`MetricCard` renders its value in the monospaced financial face, so it aligns in a grid of currency figures. Lay several out in a `display:grid` with `gap:16px`. `Callout` is a soft-amber advisory band — use for non-blocking configuration/notice messages, not for inline form errors (use InlineError for those).
