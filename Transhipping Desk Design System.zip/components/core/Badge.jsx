import React from 'react'

const TONES = {
  blue: 'app-badge--blue',
  green: 'app-badge--green',
  red: 'app-badge--red',
  yellow: 'app-badge--yellow',
  slate: 'app-badge--slate',
}

/**
 * Compact uppercase status pill used throughout tables and detail views to
 * signal invoice status, CE Mercante state, linkage, and the like.
 */
export function Badge({ tone = 'slate', className = '', children, ...props }) {
  const classes = ['app-badge', TONES[tone] || TONES.slate, className].filter(Boolean).join(' ')
  return (
    <span className={classes} {...props}>
      {children}
    </span>
  )
}
