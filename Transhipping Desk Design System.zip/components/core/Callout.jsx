import React from 'react'

/**
 * A bordered callout for advisory messages. The "warning" variant (soft amber)
 * is the canonical use — e.g. missing configuration on the login screen.
 */
export function Callout({ variant = 'warning', className = '', children, ...props }) {
  const classes = ['app-callout', `app-callout--${variant}`, className].filter(Boolean).join(' ')
  return (
    <div className={classes} {...props}>
      {children}
    </div>
  )
}
