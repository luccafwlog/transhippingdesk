import React from 'react'

/**
 * A small labelled metric tile — uppercase label over a large value. Used in
 * grids across the customer portal (Saldo pendente, Faturas emitidas) and
 * invoice detail summaries.
 */
export function MetricCard({ label, value, className = '', ...props }) {
  const classes = ['app-metric-tile', className].filter(Boolean).join(' ')
  return (
    <div className={classes} {...props}>
      <div className="app-metric-tile__label">{label}</div>
      <div className="app-metric-tile__value financial">{value}</div>
    </div>
  )
}
