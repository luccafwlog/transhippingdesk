import * as React from 'react'

/**
 * Compact uppercase status pill for tables and detail views.
 *
 * @startingPoint section="Core" subtitle="Status pills in every tone" viewport="700x140"
 */
export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Semantic color. blue=info/issued, green=paid/ready, red=overdue, yellow=review/warning, slate=neutral. @default "slate" */
  tone?: 'blue' | 'green' | 'red' | 'yellow' | 'slate'
}

export function Badge(props: BadgeProps): React.JSX.Element
