import * as React from 'react'

/** Bordered advisory message block. */
export interface CalloutProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Visual tone. @default "warning" */
  variant?: 'warning'
}

export function Callout(props: CalloutProps): React.JSX.Element
