import * as React from 'react'

/**
 * Primary action control. Variants map to operational hierarchy.
 *
 * @startingPoint section="Core" subtitle="Buttons in every variant & size" viewport="700x180"
 */
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Visual emphasis. @default "primary" */
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost'
  /** Control height. @default "md" */
  size?: 'md' | 'sm'
  /** Replaces children with a loading label and disables the button. */
  loading?: boolean
}

export function Button(props: ButtonProps): React.JSX.Element
