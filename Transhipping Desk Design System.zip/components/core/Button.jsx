import React from 'react'

const VARIANTS = {
  primary: 'app-btn--primary',
  secondary: 'app-btn--secondary',
  danger: 'app-btn--danger',
  ghost: 'app-btn--ghost',
}

/**
 * Primary action control for the Transhipping Desk. Four variants map to the
 * operational hierarchy: primary (navy-blue fill) for the main action,
 * secondary (outline) for supporting actions, danger for destructive, ghost
 * for low-emphasis toolbar actions.
 */
export function Button({
  variant = 'primary',
  size = 'md',
  loading = false,
  disabled = false,
  type = 'button',
  className = '',
  children,
  ...props
}) {
  const classes = [
    'app-btn',
    VARIANTS[variant] || VARIANTS.primary,
    size === 'sm' ? 'app-btn--sm' : '',
    className,
  ]
    .filter(Boolean)
    .join(' ')

  return (
    <button type={type} className={classes} disabled={disabled || loading} {...props}>
      {loading ? 'Carregando...' : children}
    </button>
  )
}
