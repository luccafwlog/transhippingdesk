import * as React from 'react'

/**
 * Small labelled metric tile: uppercase label over a large monospaced value.
 */
export interface MetricCardProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Uppercase caption above the value. */
  label: React.ReactNode
  /** The figure — rendered in the monospaced financial face. */
  value: React.ReactNode
}

export function MetricCard(props: MetricCardProps): React.JSX.Element
