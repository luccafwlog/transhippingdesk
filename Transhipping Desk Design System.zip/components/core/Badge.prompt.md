One-line: A small uppercase status pill for invoice/operational state — the workhorse signal across every table.

```jsx
<Badge tone="blue">Emitida</Badge>
<Badge tone="green">Pago</Badge>
<Badge tone="red">Vencida</Badge>
<Badge tone="yellow">Revisão</Badge>
<Badge tone="slate">Cancelada</Badge>
```

Tones carry fixed meaning in this product: `green` = paid/ready_for_billing, `blue` = issued/info/consolidated, `yellow` = review_required/warning, `red` = overdue/danger, `slate` = neutral/cancelled. Always uppercase, always pill-shaped. Keep labels to 1–2 words in Portuguese (Emitida, Pago, Vencida, Revisão).
