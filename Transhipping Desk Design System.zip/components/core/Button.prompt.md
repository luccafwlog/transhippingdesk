One-line: The primary clickable action — navy-blue fill for the main action, outline/ghost for support, danger for destructive.

```jsx
<Button onClick={save}>Entrar</Button>
<Button variant="secondary"><RefreshCw size={14} /> Atualizar</Button>
<Button variant="danger" size="sm">Excluir</Button>
<Button variant="ghost"><LogOut size={16} /> Sair</Button>
<Button loading>Carregando…</Button>
```

Variants: `primary` (default, navy-blue `--app-blue-btn`), `secondary` (white outline that turns blue on hover), `danger` (soft-red), `ghost` (transparent toolbar action). Sizes: `md` (44px, default), `sm` (36px). Icons are lucide glyphs placed inline before the label; the gap is handled by the component. Use exactly one primary button per view.
