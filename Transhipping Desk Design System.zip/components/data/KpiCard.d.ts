import * as React from 'react'

/**
 * Dashboard KPI card with colored accent rail and large monospaced value.
 *
 * @startingPoint section="Data" subtitle="Dashboard KPI tiles" viewport="700x220"
 */
export interface KpiCardProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Left-rail + value color. green=financial, gold=review, blue=count, navy=neutral. @default "navy" */
  accent?: 'navy' | 'blue' | 'green' | 'gold'
  /** Optional icon node (lucide glyph). */
  icon?: React.ReactNode
  /** Uppercase caption. */
  label: React.ReactNode
  /** Large figure. */
  value: React.ReactNode
  /** Optional sub-detail line below the value. */
  detail?: React.ReactNode
}

export function KpiCard(props: KpiCardProps): React.JSX.Element
