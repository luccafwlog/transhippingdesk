import React from 'react'

/**
 * Dashboard KPI card — a large monospaced figure under an uppercase label,
 * with a colored left accent rail and optional icon + sub-detail. The accent
 * encodes meaning: green=financial-ready, gold=needs-review, blue=count,
 * navy=neutral.
 */
export function KpiCard({ accent = 'navy', icon, label, value, detail, className = '', ...props }) {
  const classes = ['app-surface', 'app-surface--padded', 'app-kpi-card', `app-kpi-card--${accent}`, 'painel-kpi-card', className]
    .filter(Boolean)
    .join(' ')
  return (
    <div className={classes} {...props}>
      {icon ? <div className="painel-kpi-card__icon">{icon}</div> : null}
      <div className="painel-kpi-card__copy">
        <div className="app-kpi-card__label">{label}</div>
        <div className={`app-kpi-card__value app-kpi-card__value--${accent}`}>{value}</div>
      </div>
      <div className="app-kpi-card__sub">{detail ?? ''}</div>
    </div>
  )
}
