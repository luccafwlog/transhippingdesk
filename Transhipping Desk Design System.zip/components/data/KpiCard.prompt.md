One-line: The dashboard KPI tile — a big monospaced number with an uppercase caption, a colored left accent rail, and an optional icon and sub-detail.

```jsx
<div className="grid gap-4" style={{ gridTemplateColumns: 'repeat(4, 1fr)' }}>
  <KpiCard accent="navy"  icon={<FileText size={24} />}     label="B/Ls ativos" value="142" />
  <KpiCard accent="blue"  icon={<Boxes size={24} />}        label="Containers distintos" value="3.480" />
  <KpiCard accent="gold"  icon={<AlertTriangle size={24} />} label="Aguardando revisão" value="7" />
  <KpiCard accent="green" icon={<Receipt size={24} />}      label="Faturas em aberto" value="18" detail={formatBRL(243000)} />
</div>
```

Accent semantics are fixed: `green` = ready-to-bill / paid figures, `gold` = needs-review counts, `blue` = distinct counts, `navy` = neutral totals. The value renders in IBM Plex Mono so columns of figures align. Icons are lucide-react, size 24.
