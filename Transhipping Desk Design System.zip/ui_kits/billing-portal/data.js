// Mock customer-portal data for the Transhipping billing portal. All fictional.
window.PORTAL_DATA = {
  customer: { name: 'Granito Serra Azul Ltda', cnpj: '12.345.678/0001-90', pending: 'R$ 27.340,00' },
  local: [
    { id: 3120, num: 'INV-3120', bls: ['MAEU7781234'], type: 'consolidated', issued: '02/06/2026', total: 'R$ 8.420,00', status: 'issued' },
    { id: 3118, num: 'INV-3118', bls: ['MAEU7781190'], type: 'single', issued: '29/05/2026', total: 'R$ 4.260,00', status: 'overdue' },
    { id: 3109, num: 'INV-3109', bls: ['MSKU8890021', 'MSKU8890022'], type: 'consolidated', issued: '24/05/2026', total: 'R$ 14.660,00', status: 'paid' },
    { id: 3101, num: 'INV-3101', bls: ['MAEU7780041'], type: 'single', issued: '18/05/2026', total: 'R$ 3.980,00', status: 'paid' },
  ],
  demurrage: [
    { id: 880, num: 'DEM-0880', bl: 'MAEU7781234', leg: 'CNSHA / BRSSZ', issued: '03/06/2026', due: '18/06/2026', usd: '$ 1.240,00', brl: 'R$ 6.720,00', status: 'issued' },
    { id: 876, num: 'DEM-0876', bl: 'MSKU8890021', leg: 'CNNGB / BRRIG', issued: '27/05/2026', due: '11/06/2026', usd: '$ 2.180,00', brl: 'R$ 11.820,00', status: 'overdue' },
    { id: 870, num: 'DEM-0870', bl: 'MAEU7780041', leg: 'CNSHA / BRSSZ', issued: '15/05/2026', due: '30/05/2026', usd: '$ 640,00', brl: 'R$ 3.470,00', status: 'paid' },
  ],
  detail: {
    bls: [
      { bl: 'MAEU7781234', vessel: 'MSC Carolina / 512N', leg: 'CNSHA - BRSSZ', subtotal: 'R$ 8.420,00' },
    ],
    items: [
      { desc: 'THC — Terminal Handling', bl: 'MAEU7781234', qty: 12, unit: 'R$ 480,00', total: 'R$ 5.760,00' },
      { desc: 'Liberação documental (BL)', bl: 'MAEU7781234', qty: 1, unit: 'R$ 920,00', total: 'R$ 920,00' },
      { desc: 'Taxa de desconsolidação', bl: 'MAEU7781234', qty: 1, unit: 'R$ 740,00', total: 'R$ 740,00' },
      { desc: 'ISPS / Security', bl: 'MAEU7781234', qty: 12, unit: 'R$ 83,33', total: 'R$ 1.000,00' },
    ],
  },
};
