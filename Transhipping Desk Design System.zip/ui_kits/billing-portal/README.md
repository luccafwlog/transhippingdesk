# UI Kit — Customer Billing Portal

The external, customer-facing portal where a shipper logs in to view and pay their
invoices. Recreated from `src/pages/PortalBilling.tsx` and
`src/components/layout/PortalLayout.tsx`.

## Screen
- **Faturas** — the portal home. Three metric tiles (Saldo pendente / Faturas emitidas / B/Ls elegíveis), then an **underline tab strip** switching between **Taxas Locais** and **Demurrage** tables. Each row opens a detail **Modal** with the charged-items breakdown and a **PIX** payment block (QR + copia-e-cola string).
- **Operação** — stubbed with an EmptyState (out of scope for this kit).

## Chrome
Reuses the design-system shell with a leaner header: reversed logo, "Portal do cliente" eyebrow, the customer name in a building pill, and two pill tabs (Faturas / Operação). No market strip — customers don't see internal FX/alerts.

## How it's built
Loads React + Babel, Lucide (icons), the compiled `_ds_bundle.js`, then `data.js`
and `PortalBilling.jsx`. Primitives come from the bundle; tables use `.app-table`
classes. Demurrage is billed in USD with a frozen BRL total, matching the product.

All data in `data.js` is fictional. The PIX QR is a decorative placeholder.
