/* global React */
const Icon = window.Icon;

const LOCAL_STATUS = {
  paid: { tone: 'green', label: 'Pago' },
  partial: { tone: 'blue', label: 'Parcial' },
  overdue: { tone: 'yellow', label: 'Vencida' },
  issued: { tone: 'blue', label: 'Emitida' },
};
const DEM_STATUS = {
  paid: { tone: 'green', label: 'Pago' },
  overdue: { tone: 'red', label: 'Vencida' },
  issued: { tone: 'blue', label: 'Emitida' },
};

function fmtBl(bls) {
  if (bls.length <= 2) return bls.join(', ');
  return `${bls.slice(0, 2).join(', ')} +${bls.length - 2}`;
}

function PortalBilling({ data, NS }) {
  const { PageHeader, Card, Button, Badge, Field, Input, Select, FilterBar, MetricCard, Modal } = NS;
  const [tab, setTab] = React.useState('local');
  const [status, setStatus] = React.useState('');
  const [detail, setDetail] = React.useState(null);

  const localRows = data.local.filter((i) => !status || i.status === status);
  const demRows = data.demurrage.filter((i) => !status || i.status === status);

  return (
    <>
      <PageHeader
        title="Faturas"
        description="Consulte suas faturas, pague via PIX e consolide B/Ls em aberto."
        action={<Button><Icon name="file-plus-2" size={16} /> Gerar fatura consolidada</Button>}
      />

      <div style={{ display: 'grid', gap: 16, gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))', marginBottom: 20 }}>
        <MetricCard label="Saldo pendente" value={data.customer.pending} />
        <MetricCard label="Faturas emitidas" value={String(data.local.length)} />
        <MetricCard label="B/Ls elegíveis" value="3" />
      </div>

      <div style={{ display: 'flex', gap: 8, borderBottom: '1px solid var(--app-border)', marginBottom: 16 }}>
        <button type="button" className={`tab-underline${tab === 'local' ? ' tab-underline--active' : ''}`} onClick={() => setTab('local')}>Taxas Locais</button>
        <button type="button" className={`tab-underline${tab === 'demurrage' ? ' tab-underline--active' : ''}`} onClick={() => setTab('demurrage')}>Demurrage</button>
      </div>

      <Card padded={false}>
        <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--app-border)' }}>
          <div style={{ fontSize: 16, fontWeight: 700, color: 'var(--app-text-strong)' }}>
            {tab === 'local' ? 'Faturas de taxas locais' : 'Sobreestadia de containers (D&D)'}
          </div>
          <div style={{ marginTop: 4, fontSize: 13, color: 'var(--app-muted)' }}>
            {(tab === 'local' ? localRows.length : demRows.length)} fatura(s)
          </div>
        </div>

        <div style={{ padding: '14px 20px 0' }}>
          <FilterBar activeCount={status ? 1 : 0} defaultOpen onClear={() => setStatus('')}>
            <div className="app-filter-grid">
              <Field label="Status">
                <Select value={status} onChange={(e) => setStatus(e.target.value)}>
                  <option value="">Todos</option>
                  <option value="issued">Emitida</option>
                  <option value="paid">Paga</option>
                  <option value="overdue">Vencida</option>
                </Select>
              </Field>
              <Field label="Navio/Viagem"><Input placeholder="Digite o navio ou viagem" /></Field>
              <Field label="B/L"><Input placeholder="Número do B/L" /></Field>
              <Field label="Emissão (de)"><Input type="date" /></Field>
            </div>
          </FilterBar>
        </div>

        <div className="app-table-scroll">
          {tab === 'local' ? (
            <table className="app-table app-table--compact" style={{ minWidth: 760 }}>
              <thead>
                <tr><th style={{ textAlign: 'left' }}>Fatura</th><th style={{ textAlign: 'left' }}>B/L</th><th style={{ textAlign: 'left' }}>Tipo</th><th style={{ textAlign: 'left' }}>Emissão</th><th style={{ textAlign: 'left' }}>Total</th><th style={{ textAlign: 'left' }}>Status</th><th style={{ textAlign: 'left' }}>Ação</th></tr>
              </thead>
              <tbody>
                {localRows.map((inv) => (
                  <tr key={inv.id}>
                    <td style={{ fontWeight: 700, color: 'var(--app-text-strong)' }}>{inv.num}</td>
                    <td className="financial">{fmtBl(inv.bls)}</td>
                    <td>{inv.type === 'consolidated' ? 'Consolidada' : 'Individual'}</td>
                    <td className="financial">{inv.issued}</td>
                    <td className="financial" style={{ fontWeight: 700, color: 'var(--app-text-strong)' }}>{inv.total}</td>
                    <td><Badge tone={LOCAL_STATUS[inv.status].tone}>{LOCAL_STATUS[inv.status].label}</Badge></td>
                    <td><Button variant="secondary" size="sm" onClick={() => setDetail(inv)}>Detalhes</Button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <table className="app-table app-table--compact" style={{ minWidth: 820 }}>
              <thead>
                <tr><th style={{ textAlign: 'left' }}>Documento</th><th style={{ textAlign: 'left' }}>BL / Trecho</th><th style={{ textAlign: 'left' }}>Emissão</th><th style={{ textAlign: 'left' }}>Vencimento</th><th style={{ textAlign: 'left' }}>Total USD</th><th style={{ textAlign: 'left' }}>Total BRL</th><th style={{ textAlign: 'left' }}>Status</th><th style={{ textAlign: 'left' }}>Ação</th></tr>
              </thead>
              <tbody>
                {demRows.map((inv) => (
                  <tr key={inv.id}>
                    <td style={{ fontWeight: 700, color: 'var(--app-text-strong)' }}>{inv.num}</td>
                    <td><span className="financial" style={{ fontWeight: 600 }}>{inv.bl}</span> · {inv.leg}</td>
                    <td className="financial">{inv.issued}</td>
                    <td className="financial">{inv.due}</td>
                    <td className="financial">{inv.usd}</td>
                    <td className="financial" style={{ fontWeight: 700, color: 'var(--app-text-strong)' }}>{inv.brl}</td>
                    <td><Badge tone={DEM_STATUS[inv.status].tone}>{DEM_STATUS[inv.status].label}</Badge></td>
                    <td><Button variant="secondary" size="sm" onClick={() => setDetail(inv)}>Detalhes</Button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </Card>

      <Modal open={Boolean(detail)} onClose={() => setDetail(null)} title={`Fatura ${detail ? detail.num : ''}`}>
        {detail ? (
          <div style={{ display: 'grid', gap: 20 }}>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
              <Button variant="secondary" size="sm"><Icon name="printer" size={16} /> Imprimir PDF</Button>
              <Button size="sm">Pagar via PIX</Button>
            </div>
            <div style={{ display: 'grid', gap: 12, gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))' }}>
              <MetricCard label="Status" value={(LOCAL_STATUS[detail.status] || DEM_STATUS[detail.status]).label} />
              <MetricCard label="Total" value={detail.total || detail.brl} />
              <MetricCard label="Emissão" value={detail.issued} />
              <MetricCard label="B/Ls" value={String(detail.bls ? detail.bls.length : 1)} />
            </div>

            <Card padded={false}>
              <div style={{ padding: '12px 16px', borderBottom: '1px solid var(--app-border)' }}>
                <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--app-text-strong)' }}>Itens cobrados</div>
                <div style={{ fontSize: 12, color: 'var(--app-muted)', marginTop: 2 }}>Taxas, quantidades e valores</div>
              </div>
              <div className="app-table-scroll">
                <table className="app-table app-table--compact" style={{ minWidth: 560 }}>
                  <thead><tr><th style={{ textAlign: 'left' }}>Descrição</th><th style={{ textAlign: 'left' }}>B/L</th><th style={{ textAlign: 'right' }}>Qtd</th><th style={{ textAlign: 'right' }}>Valor unit.</th><th style={{ textAlign: 'right' }}>Total</th></tr></thead>
                  <tbody>
                    {data.detail.items.map((it, i) => (
                      <tr key={i}>
                        <td>{it.desc}</td>
                        <td className="financial">{it.bl}</td>
                        <td style={{ textAlign: 'right' }} className="financial">{it.qty}</td>
                        <td style={{ textAlign: 'right' }} className="financial">{it.unit}</td>
                        <td style={{ textAlign: 'right', fontWeight: 700, color: 'var(--app-text-strong)' }} className="financial">{it.total}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>

            <Card>
              <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--app-text-strong)', marginBottom: 12 }}>Pagamento via PIX</div>
              <div style={{ display: 'flex', gap: 18, alignItems: 'center', flexWrap: 'wrap' }}>
                <div style={{ width: 116, height: 116, borderRadius: 10, border: '1px solid var(--app-border)', background: 'repeating-conic-gradient(var(--app-navy) 0% 25%, #ffffff 0% 50%) 50% / 16px 16px' }} aria-label="QR Code PIX" />
                <div>
                  <div style={{ fontSize: 12, color: 'var(--app-muted)', marginBottom: 4 }}>Copia e cola</div>
                  <div className="financial" style={{ maxWidth: 280, wordBreak: 'break-all', borderRadius: 8, background: 'var(--app-surface-muted)', padding: 10, fontSize: 12 }}>
                    00020126580014br.gov.bcb.pix0136a1b2c3d4-transhipping-520400005303986540{(detail.total || detail.brl).replace(/\D/g, '')}5802BR6009SAO PAULO
                  </div>
                </div>
              </div>
            </Card>
          </div>
        ) : null}
      </Modal>
    </>
  );
}

window.PortalBilling = PortalBilling;
