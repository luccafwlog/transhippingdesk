/* global React */
// App chrome: dark market strip, navy header, gold-ruled nav. Uses DS CSS classes.
const Icon = window.Icon;

function MarketStrip({ user, rates, alerts }) {
  return (
    <div className="app-market-strip">
      <div className="app-market-strip__content">
        <div className="app-market-strip__left">
          <button className="hib-alert-btn" type="button">
            <Icon name="alert-triangle" size={11} />
            {alerts.demurrage} demurrages vencidos
          </button>
          <span className="hib-sep">·</span>
          <button className="hib-alert-btn" type="button">{alerts.granite} Granite pendente</button>
        </div>
        <div className="app-market-strip__center">
          <span className="hib-currency-label">USD</span>
          <span className="hib-currency-value">R$ {rates.usd}</span>
          <span className="hib-sep">·</span>
          <span className="hib-currency-label">CNY</span>
          <span className="hib-currency-value">R$ {rates.cny}</span>
        </div>
        <div className="app-market-strip__right">
          <button className="hib-user-btn" type="button">
            <Icon name="user-circle" size={13} />
            <span className="hib-user-name">{user.name}</span>
            <span className="hib-sep">·</span>
            <span className="hib-user-role">{user.role}</span>
          </button>
        </div>
      </div>
    </div>
  );
}

const NAV = [
  { id: 'painel', label: 'Painel', icon: 'home' },
  { id: 'viagens', label: 'Viagens', icon: 'ship' },
  { id: 'importacao', label: 'Importação', icon: 'file-spreadsheet', dropdown: true },
  { id: 'exportacao', label: 'Exportação', icon: 'package', dropdown: true },
  { id: 'clientes', label: 'Clientes', icon: 'users' },
  { id: 'alertas', label: 'Alertas', icon: 'bell', badge: 5 },
  { id: 'faturamento', label: 'Financeiro', icon: 'dollar-sign', dropdown: true, alert: true },
];

function AppChrome({ user, rates, alerts, active, onNavigate, onSignOut }) {
  return (
    <>
      <MarketStrip user={user} rates={rates} alerts={alerts} />
      <header className="app-header">
        <div className="app-header__content">
          <button className="app-header__brand" type="button" onClick={() => onNavigate('painel')}>
            <img className="app-header__brand-logo" src="assets/logo-white.png" alt="Transhipping" />
            <div className="app-header__titles">
              <div className="app-header__eyebrow">Desk operacional</div>
              <div className="app-header__subtitle">importação, exportação e faturamento</div>
            </div>
          </button>
          <div className="app-header__actions">
            <div className="app-user-pill">
              <span className="app-user-pill__icon"><Icon name="user" size={14} /></span>
              <span className="app-user-pill__name">{user.name}</span>
            </div>
            <button className="app-btn app-btn--ghost app-header__logout" type="button" onClick={onSignOut}>
              <Icon name="log-out" size={16} /> Sair
            </button>
          </div>
        </div>
      </header>
      <div className="app-nav-bar">
        <nav className="app-nav-scroll">
          {NAV.map((item) => {
            const isActive = active === item.id || (item.id === 'faturamento' && active === 'faturamento');
            return (
              <button
                key={item.id}
                type="button"
                className={`app-nav-link app-nav-link--button${isActive ? ' active' : ''}`}
                onClick={() => onNavigate(item.id === 'importacao' || item.id === 'exportacao' ? active : item.id)}
              >
                <Icon name={item.icon} size={18} />
                {item.label}
                {item.badge ? <span className="app-nav-badge">{item.badge}</span> : null}
                {item.alert ? <span className="app-nav-alert-dot" /> : null}
                {item.dropdown ? <Icon name="chevron-down" size={16} className="app-nav-dropdown__chevron" /> : null}
              </button>
            );
          })}
        </nav>
      </div>
    </>
  );
}

window.AppChrome = AppChrome;
