/* global React */
const Icon = window.Icon;

const INV_STATUS = {
  paid: { tone: 'green', label: 'Paga' },
  partial: { tone: 'blue', label: 'Parcial' },
  overdue: { tone: 'red', label: 'Vencida' },
  issued: { tone: 'blue', label: 'Emitida' },
};

function FaturamentoScreen({ data, NS }) {
  const { PageHeader, Card, Button, Badge, Field, Input, Select, FilterBar, MetricCard, Modal } = NS;
  const [status, setStatus] = React.useState('');
  const [query, setQuery] = React.useState('');
  const [selected, setSelected] = React.useState(null);

  const rows = data.invoices.filter((i) =>
    (!status || i.status === status) &&
    (!query || i.customer.toLowerCase().includes(query.toLowerCase()) || i.num.toLowerCase().includes(query.toLowerCase()))
  );
  const activeCount = (status ? 1 : 0) + (query ? 1 : 0);

  return (
    <>
      <PageHeader
        title="Faturamento"
        description="Faturas de taxas locais emitidas para os clientes, com situação financeira e status de pagamento."
        action={<Button><Icon name="file-plus-2" size={16} /> Gerar fatura consolidada</Button>}
      />

      <div style={{ display: 'grid', gap: 16, gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', marginBottom: 20 }}>
        <MetricCard label="Total faturado (mês)" value="R$ 243.180,00" />
        <MetricCard label="Recebido" value="R$ 161.080,00" />
        <MetricCard label="Em aberto" value="R$ 82.100,00" />
        <MetricCard label="Faturas vencidas" value="1" />
      </div>

      <FilterBar activeCount={activeCount} defaultOpen onClear={() => { setStatus(''); setQuery(''); }}>
        <div className="app-filter-grid">
          <Field label="Buscar"><Input placeholder="Cliente ou nº da fatura" value={query} onChange={(e) => setQuery(e.target.value)} /></Field>
          <Field label="Status">
            <Select value={status} onChange={(e) => setStatus(e.target.value)}>
              <option value="">Todos</option>
              <option value="issued">Emitida</option>
              <option value="partial">Parcial</option>
              <option value="paid">Paga</option>
              <option value="overdue">Vencida</option>
            </Select>
          </Field>
          <Field label="POD"><Select><option>Todos</option><option>BRSSZ</option><option>BRRIG</option></Select></Field>
          <Field label="Emissão (de)"><Input type="date" /></Field>
        </div>
      </FilterBar>

      <Card padded={false}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 8, padding: '14px 16px', borderBottom: '1px solid var(--app-border)' }}>
          <span style={{ fontWeight: 700, color: 'var(--app-text-strong)' }}>{rows.length} fatura(s) retornada(s)</span>
          <span style={{ fontSize: 12, color: 'var(--app-muted)' }}>Ordenado por emissão (recente)</span>
        </div>
        <div className="app-table-scroll">
          <table className="app-table app-table--compact" style={{ minWidth: 1080 }}>
            <thead>
              <tr>
                <th style={{ textAlign: 'left' }}>Fatura</th><th style={{ textAlign: 'left' }}>B/L</th>
                <th style={{ textAlign: 'left' }}>Tipo</th><th style={{ textAlign: 'left' }}>Navio / Viagem · POD</th>
                <th style={{ textAlign: 'left' }}>Emissão</th><th style={{ textAlign: 'left' }}>Financeiro</th>
                <th style={{ textAlign: 'left' }}>Status</th><th style={{ textAlign: 'left' }}>Ações</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((inv) => (
                <tr key={inv.id}>
                  <td>
                    <div style={{ fontWeight: 700, color: 'var(--app-text-strong)' }}>{inv.num}</div>
                    <div style={{ fontSize: 12, color: 'var(--app-muted)' }}>{inv.customer}</div>
                    <div style={{ fontSize: 12, color: 'var(--app-muted-soft)' }} className="financial">{inv.cnpj}</div>
                  </td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <span style={{ fontWeight: 700, color: 'var(--app-blue)' }}>{inv.bls[0]}</span>
                      <Badge tone={inv.type === 'consolidated' ? 'blue' : 'slate'}>{inv.bls.length} B/L{inv.bls.length > 1 ? 's' : ''}</Badge>
                    </div>
                  </td>
                  <td><Badge tone={inv.type === 'consolidated' ? 'blue' : 'slate'}>{inv.type === 'consolidated' ? 'Consolidada' : 'Único BL'}</Badge></td>
                  <td>
                    <div style={{ fontWeight: 600 }}>{inv.vessel}</div>
                    <div style={{ fontSize: 12, color: 'var(--app-muted)' }}>POD {inv.pod}</div>
                  </td>
                  <td className="financial">{inv.issued}</td>
                  <td>
                    <div className="financial" style={{ fontWeight: 700, color: 'var(--app-text-strong)' }}>Total {inv.total}</div>
                    <div className="financial" style={{ fontSize: 12, color: 'var(--app-muted)' }}>Saldo {inv.balance}</div>
                  </td>
                  <td><Badge tone={INV_STATUS[inv.status].tone}>{INV_STATUS[inv.status].label}</Badge></td>
                  <td><Button variant="secondary" size="sm" onClick={() => setSelected(inv)}>Detalhes</Button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="app-table__footer">
          <span>Página 1 de 1 · {rows.length} registros</span>
          <div className="app-table__footer-controls">
            <Button variant="secondary" size="sm" disabled>Anterior</Button>
            <Button variant="secondary" size="sm" disabled>Próxima</Button>
          </div>
        </div>
      </Card>

      <Modal open={Boolean(selected)} onClose={() => setSelected(null)} title={`Fatura ${selected ? selected.num : ''}`}>
        {selected ? (
          <div style={{ display: 'grid', gap: 20 }}>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, flexWrap: 'wrap' }}>
              <Button variant="ghost" size="sm"><Icon name="rotate-ccw" size={16} /> Refazer consolidada</Button>
              <Button variant="secondary" size="sm"><Icon name="printer" size={16} /> Imprimir PDF</Button>
            </div>
            <div style={{ display: 'grid', gap: 12, gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))' }}>
              <MetricCard label="Status" value={INV_STATUS[selected.status].label} />
              <MetricCard label="Total" value={selected.total} />
              <MetricCard label="Pago" value={selected.paid} />
              <MetricCard label="Saldo" value={selected.balance} />
              <MetricCard label="B/Ls" value={String(selected.bls.length)} />
            </div>
            <Card padded={false}>
              <div style={{ padding: '12px 16px', borderBottom: '1px solid var(--app-border)' }}>
                <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--app-text-strong)' }}>Itens cobrados</div>
                <div style={{ fontSize: 12, color: 'var(--app-muted)', marginTop: 2 }}>Taxas, quantidades e valores</div>
              </div>
              <div className="app-table-scroll">
                <table className="app-table app-table--compact" style={{ minWidth: 560 }}>
                  <thead>
                    <tr><th style={{ textAlign: 'left' }}>Descrição</th><th style={{ textAlign: 'left' }}>B/L</th><th style={{ textAlign: 'right' }}>Qtd</th><th style={{ textAlign: 'right' }}>Valor unit.</th><th style={{ textAlign: 'right' }}>Total</th></tr>
                  </thead>
                  <tbody>
                    {data.invoiceItems.map((it, i) => (
                      <tr key={i}>
                        <td>{it.desc}</td>
                        <td className="financial">{it.bl}</td>
                        <td style={{ textAlign: 'right' }} className="financial">{it.qty}</td>
                        <td style={{ textAlign: 'right' }} className="financial">{it.unit}</td>
                        <td style={{ textAlign: 'right', fontWeight: 700, color: 'var(--app-text-strong)' }} className="financial">{it.total}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        ) : null}
      </Modal>
    </>
  );
}

window.FaturamentoScreen = FaturamentoScreen;
