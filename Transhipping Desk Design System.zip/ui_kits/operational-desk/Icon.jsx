/* global React */
// Lucide icon → clean inline SVG (uses copied lucide icon data, no hand-drawing).
const ICON_ALIAS = {
  ship: 'Ship', home: 'Home', users: 'Users', bell: 'Bell', 'file-spreadsheet': 'FileSpreadsheet',
  package: 'Package', 'dollar-sign': 'DollarSign', boxes: 'Boxes', 'alert-triangle': 'AlertTriangle',
  receipt: 'Receipt', 'file-text': 'FileText', monitor: 'Monitor', 'refresh-cw': 'RefreshCw',
  'check-circle': 'CheckCircle', 'user-x': 'UserX', 'receipt-text': 'ReceiptText', 'chevron-down': 'ChevronDown',
  user: 'User', 'log-out': 'LogOut', 'building-2': 'Building2', 'file-plus-2': 'FilePlus2', printer: 'Printer',
  'rotate-ccw': 'RotateCcw', x: 'X', 'user-circle': 'UserCircle', inbox: 'Inbox', search: 'Search',
  'table-properties': 'TableProperties', mountain: 'Mountain', clock: 'Clock', car: 'Car', 'alert-circle': 'AlertCircle',
};

function Icon({ name, size = 16, strokeWidth = 2, style, className }) {
  const key = ICON_ALIAS[name] || name;
  const node = (window.lucide && window.lucide.icons && window.lucide.icons[key]) || null;
  if (!node) {
    return <svg width={size} height={size} viewBox="0 0 24 24" style={style} className={className} />;
  }
  // Lucide stores each icon as ["svg", {attrs}, [ [tag, {geom}], ... ]] — children are node[2].
  const childNodes = Array.isArray(node) && Array.isArray(node[2]) ? node[2] : [];
  return (
    <svg
      width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor"
      strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round"
      style={style} className={className} aria-hidden="true"
    >
      {childNodes.map(([tag, attrs], i) => React.createElement(tag, { key: i, ...attrs }))}
    </svg>
  );
}

window.Icon = Icon;
