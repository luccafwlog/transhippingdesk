# UI Kit — Internal Operational Desk

The internal-facing console used by Transhipping's operations, documentation and
finance teams. Recreated from the product source (`src/pages/Painel.tsx`,
`src/components/layout/*`, `src/components/billing/*`).

## Screens
- **Login** (`app-auth`) — split branding panel (navy, gold rule, reversed logo) + credential form.
- **Painel** — the home dashboard: pill-tab filters over the **Line Up** vessel board, then a grid of KPI cards (accent rails encode meaning).
- **Faturamento** — local-fee invoices: metric tiles, a collapsible filter bar, a dense data table with status badges, and an invoice-detail **Modal** with the charged-items breakdown.

## Chrome
Three stacked bands, all token-driven:
1. **Market strip** — darkest band: operational alerts (amber) · PTAX FX (USD/CNY, mono) · logged-in user.
2. **Header** — navy gradient, reversed logo, "Desk operacional" eyebrow, user pill + Sair.
3. **Nav bar** — navy-2 with a 2px gold bottom rule; the active item carries an inset gold underline. Dropdown sections (Importação, Exportação, Financeiro) show a chevron; counts render as gold badges, pending review as an alert dot.

## How it's built
`index.html` loads React + Babel, **Lucide** (icons, via UMD → clean inline SVG in `Icon.jsx`), the compiled `_ds_bundle.js`, then `data.js` and the screen files. UI primitives (`Button`, `Badge`, `Card`, `KpiCard`, `MetricCard`, `Field`, `Input`, `Select`, `FilterBar`, `Modal`, `PageHeader`) come from the design-system bundle; tables use the `.app-table` classes directly, exactly as the real product does.

All data in `data.js` is fictional.
