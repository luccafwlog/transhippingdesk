// Mock operational data for the Transhipping Desk UI kit. All fictional.
window.DESK_DATA = {
  user: { name: 'Ana Duarte', role: 'Operações' },
  rates: { usd: '5,4210', cny: '0,7480' },
  alerts: { demurrage: 2, granite: 1 },
  kpis: [
    { accent: 'navy', label: 'B/Ls ativos', value: '142', detail: '' },
    { accent: 'blue', label: 'Containers distintos', value: '3.480', detail: '' },
    { accent: 'gold', label: 'Aguardando revisão', value: '7', detail: 'Ver em Revisão' },
    { accent: 'green', label: 'Faturas em aberto', value: '18', detail: 'R$ 243.000,00' },
    { accent: 'gold', label: 'Taxas para revisar', value: '4', detail: '' },
    { accent: 'green', label: 'Prontos para faturar', value: '11', detail: '' },
    { accent: 'navy', label: 'B/Ls sem cliente', value: '3', detail: 'Vincular em Revisão' },
    { accent: 'navy', label: 'Vazios IMP (MTY)', value: '612', detail: '' },
  ],
  lineup: [
    { vessel: 'MSC Carolina', voy: '512N', pod: 'BRSSZ', eta: '12/06', etb: '13/06', vin: 0, car: 18, cg: 240, total: 612, mty: 88, rtw: 4, ce: 'approved', linked: true },
    { vessel: 'Maersk Brani', voy: '233S', pod: 'BRRIG', eta: '13/06', etb: '14/06', vin: 320, car: 0, cg: 96, total: 540, mty: 124, rtw: 0, ce: 'launching', linked: true },
    { vessel: 'CMA CGM Itajaí', voy: '118N', pod: 'BRPNG', eta: '14/06', etb: '15/06', vin: 0, car: 42, cg: 410, total: 730, mty: 156, rtw: 12, ce: 'received', linked: false },
    { vessel: 'Log-In Pantanal', voy: '907N', pod: 'BRSSZ', eta: '15/06', etb: '16/06', vin: 0, car: 0, cg: 188, total: 320, mty: 60, rtw: null, ce: 'waiting', linked: false },
    { vessel: 'Aliança Brasil', voy: '441S', pod: 'BRIOA', eta: '16/06', etb: '17/06', vin: 210, car: 8, cg: 64, total: 398, mty: 92, rtw: 0, ce: 'partial', linked: true },
    { vessel: 'Hapag Rio', voy: '076N', pod: 'BRVIX', eta: '17/06', etb: '18/06', vin: 0, car: 26, cg: 302, total: 588, mty: 110, rtw: 6, ce: 'approved', linked: true },
  ],
  invoices: [
    { id: 2048, num: 'INV-2048', bls: ['MAEU7781234'], customer: 'Granito Serra Azul Ltda', cnpj: '12.345.678/0001-90', vessel: 'MSC Carolina · 512N', pod: 'BRSSZ', issued: '02/06/2026', total: 'R$ 8.420,00', paid: 'R$ 5.000,00', balance: 'R$ 3.420,00', status: 'partial', type: 'single' },
    { id: 2047, num: 'INV-2047', bls: ['CMAU2210019', 'CMAU2210020'], customer: 'Itajaí Importações S.A.', cnpj: '98.765.432/0001-10', vessel: 'CMA CGM Itajaí · 118N', pod: 'BRPNG', issued: '01/06/2026', total: 'R$ 23.180,00', paid: 'R$ 23.180,00', balance: 'R$ 0,00', status: 'paid', type: 'consolidated' },
    { id: 2046, num: 'INV-2046', bls: ['MSKU8890021'], customer: 'Vale Verde Comércio', cnpj: '45.111.222/0001-33', vessel: 'Maersk Brani · 233S', pod: 'BRRIG', issued: '28/05/2026', total: 'R$ 5.640,00', paid: 'R$ 0,00', balance: 'R$ 5.640,00', status: 'overdue', type: 'single' },
    { id: 2045, num: 'INV-2045', bls: ['HLCU3320088'], customer: 'Porto Real Logística', cnpj: '33.999.888/0001-77', vessel: 'Hapag Rio · 076N', pod: 'BRVIX', issued: '27/05/2026', total: 'R$ 12.900,00', paid: 'R$ 12.900,00', balance: 'R$ 0,00', status: 'paid', type: 'single' },
    { id: 2044, num: 'INV-2044', bls: ['ALBR4410055', 'ALBR4410056', 'ALBR4410057'], customer: 'Aliança Cargas do Sul', cnpj: '21.444.555/0001-22', vessel: 'Aliança Brasil · 441S', pod: 'BRIOA', issued: '26/05/2026', total: 'R$ 41.700,00', paid: 'R$ 20.000,00', balance: 'R$ 21.700,00', status: 'issued', type: 'consolidated' },
  ],
  invoiceItems: [
    { desc: 'THC — Terminal Handling', bl: 'MAEU7781234', qty: 12, unit: 'R$ 480,00', total: 'R$ 5.760,00' },
    { desc: 'Liberação documental (BL)', bl: 'MAEU7781234', qty: 1, unit: 'R$ 920,00', total: 'R$ 920,00' },
    { desc: 'Taxa de desconsolidação', bl: 'MAEU7781234', qty: 1, unit: 'R$ 740,00', total: 'R$ 740,00' },
    { desc: 'ISPS / Security', bl: 'MAEU7781234', qty: 12, unit: 'R$ 83,33', total: 'R$ 1.000,00' },
  ],
};
