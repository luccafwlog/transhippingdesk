/* global React */
const Icon = window.Icon;

const CE_TONE = { approved: 'green', received: 'blue', launching: 'yellow', partial: 'yellow', waiting: 'slate' };
const CE_LABEL = { approved: 'Aprovado', received: 'Recebido', launching: 'Lançando', partial: 'Parcial', waiting: 'Aguardando' };

function LineUpTable({ rows }) {
  return (
    <div className="app-table-scroll">
      <table className="app-table app-table--dense" style={{ minWidth: 980 }}>
        <thead>
          <tr>
            <th style={{ textAlign: 'left' }}>Vessel</th><th>Voy</th><th>POD</th><th>ETA</th><th>ETB</th>
            <th>VIN</th><th>CAR</th><th>CG</th><th>Total</th><th>MTY</th><th>RTW</th><th>CEs</th><th>Linked</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.vessel + r.voy}>
              <td style={{ fontWeight: 700, color: 'var(--app-text-strong)' }}>{r.vessel}</td>
              <td style={{ textAlign: 'center', fontWeight: 600 }}>{r.voy}</td>
              <td style={{ textAlign: 'center', fontWeight: 700, color: 'var(--app-blue)' }}>{r.pod}</td>
              <td style={{ textAlign: 'center' }}>{r.eta}</td>
              <td style={{ textAlign: 'center' }}>{r.etb}</td>
              <td style={{ textAlign: 'center' }} className="financial">{r.vin}</td>
              <td style={{ textAlign: 'center' }} className="financial">{r.car}</td>
              <td style={{ textAlign: 'center' }} className="financial">{r.cg}</td>
              <td style={{ textAlign: 'center', fontWeight: 700, color: 'var(--app-blue)' }} className="financial">{r.total}</td>
              <td style={{ textAlign: 'center' }} className="financial">{r.mty}</td>
              <td style={{ textAlign: 'center' }} className="financial">{r.rtw === null ? '–' : r.rtw}</td>
              <td style={{ textAlign: 'center' }}><span className={`app-badge app-badge--${CE_TONE[r.ce]}`}>{CE_LABEL[r.ce]}</span></td>
              <td style={{ textAlign: 'center' }}><span className={`app-badge app-badge--${r.linked ? 'green' : 'yellow'}`}>{r.linked ? 'SIM' : 'NÃO'}</span></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function PainelScreen({ data, NS }) {
  const { PageHeader, Card, KpiCard, Button, Badge } = NS;
  const [filter, setFilter] = React.useState('all');
  return (
    <>
      <PageHeader
        title="Painel"
        description="KPIs operacionais e quadro Line Up consolidados na página principal do sistema."
        action={
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
            <Button variant="secondary" size="sm"><Icon name="monitor" size={14} /> Abrir tela TV</Button>
            <span style={{ fontSize: 12, color: 'var(--app-muted)' }}>Atualizado: 09:12:44</span>
            <Button variant="secondary" size="sm"><Icon name="refresh-cw" size={14} /> Atualizar</Button>
          </div>
        }
      />

      <Card padded={false} style={{ marginBottom: 20 }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', gap: 16, padding: 16 }}>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            {[['all', 'Todas as escalas'], ['active', 'Escalas ativas'], ['completed', 'Concluídas']].map(([id, label]) => (
              <button key={id} type="button" className={`app-tab${filter === id ? ' app-tab--active' : ''}`} onClick={() => setFilter(id)}>{label}</button>
            ))}
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            <Badge tone="blue">ETB vinculado ao POD</Badge>
            <Badge tone="green">ATD remove a rota</Badge>
            <Badge tone="slate">Tela TV: /line-up-tv</Badge>
          </div>
        </div>
        <LineUpTable rows={data.lineup} />
        <p style={{ borderTop: '1px solid var(--app-border)', padding: '10px 16px', margin: 0, fontSize: 11, color: 'var(--app-muted)' }}>
          VIN = veículos (ro-ro) · CAR = carros em container · CG = carga geral · MTY = vazios · RTW = restow · CEs = status dos CEs Mercante · Linked = manifesto vinculado
        </p>
      </Card>

      <div style={{ display: 'grid', gap: 16, gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))', marginTop: 28 }}>
        {data.kpis.map((k) => (
          <KpiCard key={k.label} accent={k.accent} label={k.label} value={k.value} detail={k.detail} />
        ))}
      </div>
    </>
  );
}

window.PainelScreen = PainelScreen;
