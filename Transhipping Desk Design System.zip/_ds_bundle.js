/* @ds-bundle: {"format":3,"namespace":"TranshippingDeskDesignSystem_64fdac","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Callout","sourcePath":"components/core/Callout.jsx"},{"name":"MetricCard","sourcePath":"components/core/MetricCard.jsx"},{"name":"KpiCard","sourcePath":"components/data/KpiCard.jsx"},{"name":"Modal","sourcePath":"components/feedback/Modal.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Field","sourcePath":"components/forms/Field.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Textarea","sourcePath":"components/forms/Textarea.jsx"},{"name":"FilterBar","sourcePath":"components/navigation/FilterBar.jsx"},{"name":"TabButton","sourcePath":"components/navigation/TabButton.jsx"},{"name":"Card","sourcePath":"components/surfaces/Card.jsx"},{"name":"EmptyState","sourcePath":"components/surfaces/EmptyState.jsx"},{"name":"InlineError","sourcePath":"components/surfaces/InlineError.jsx"},{"name":"PageHeader","sourcePath":"components/surfaces/PageHeader.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"dc81b24d2b96","components/core/Button.jsx":"8d4239c03435","components/core/Callout.jsx":"11db58f50d9e","components/core/MetricCard.jsx":"f562b023a1e3","components/data/KpiCard.jsx":"32eb041e9c81","components/feedback/Modal.jsx":"8da1c31d4063","components/feedback/Toast.jsx":"130630860c31","components/forms/Field.jsx":"5f9c9d57fbaa","components/forms/Input.jsx":"71c7d7a9fd71","components/forms/Select.jsx":"de4c0fb8ef90","components/forms/Textarea.jsx":"ee84858e40f5","components/navigation/FilterBar.jsx":"c12038e6d76c","components/navigation/TabButton.jsx":"44014f36a9f9","components/surfaces/Card.jsx":"7ff3446c8a76","components/surfaces/EmptyState.jsx":"4ebd6139f8d7","components/surfaces/InlineError.jsx":"1c01564481e3","components/surfaces/PageHeader.jsx":"53850c9585d1","ui_kits/billing-portal/PortalBilling.jsx":"32cb9ba11a3e","ui_kits/billing-portal/data.js":"7e0a0a820b7f","ui_kits/operational-desk/AppChrome.jsx":"e75199ba1232","ui_kits/operational-desk/FaturamentoScreen.jsx":"72a35ee83e0e","ui_kits/operational-desk/Icon.jsx":"ca90268868a7","ui_kits/operational-desk/PainelScreen.jsx":"513d54c470cd","ui_kits/operational-desk/data.js":"324aa1a0f1c5"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.TranshippingDeskDesignSystem_64fdac = window.TranshippingDeskDesignSystem_64fdac || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  blue: 'app-badge--blue',
  green: 'app-badge--green',
  red: 'app-badge--red',
  yellow: 'app-badge--yellow',
  slate: 'app-badge--slate'
};

/**
 * Compact uppercase status pill used throughout tables and detail views to
 * signal invoice status, CE Mercante state, linkage, and the like.
 */
function Badge({
  tone = 'slate',
  className = '',
  children,
  ...props
}) {
  const classes = ['app-badge', TONES[tone] || TONES.slate, className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("span", _extends({
    className: classes
  }, props), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const VARIANTS = {
  primary: 'app-btn--primary',
  secondary: 'app-btn--secondary',
  danger: 'app-btn--danger',
  ghost: 'app-btn--ghost'
};

/**
 * Primary action control for the Transhipping Desk. Four variants map to the
 * operational hierarchy: primary (navy-blue fill) for the main action,
 * secondary (outline) for supporting actions, danger for destructive, ghost
 * for low-emphasis toolbar actions.
 */
function Button({
  variant = 'primary',
  size = 'md',
  loading = false,
  disabled = false,
  type = 'button',
  className = '',
  children,
  ...props
}) {
  const classes = ['app-btn', VARIANTS[variant] || VARIANTS.primary, size === 'sm' ? 'app-btn--sm' : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    className: classes,
    disabled: disabled || loading
  }, props), loading ? 'Carregando...' : children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Callout.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * A bordered callout for advisory messages. The "warning" variant (soft amber)
 * is the canonical use — e.g. missing configuration on the login screen.
 */
function Callout({
  variant = 'warning',
  className = '',
  children,
  ...props
}) {
  const classes = ['app-callout', `app-callout--${variant}`, className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("div", _extends({
    className: classes
  }, props), children);
}
Object.assign(__ds_scope, { Callout });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Callout.jsx", error: String((e && e.message) || e) }); }

// components/core/MetricCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * A small labelled metric tile — uppercase label over a large value. Used in
 * grids across the customer portal (Saldo pendente, Faturas emitidas) and
 * invoice detail summaries.
 */
function MetricCard({
  label,
  value,
  className = '',
  ...props
}) {
  const classes = ['app-metric-tile', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("div", _extends({
    className: classes
  }, props), /*#__PURE__*/React.createElement("div", {
    className: "app-metric-tile__label"
  }, label), /*#__PURE__*/React.createElement("div", {
    className: "app-metric-tile__value financial"
  }, value));
}
Object.assign(__ds_scope, { MetricCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/MetricCard.jsx", error: String((e && e.message) || e) }); }

// components/data/KpiCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Dashboard KPI card — a large monospaced figure under an uppercase label,
 * with a colored left accent rail and optional icon + sub-detail. The accent
 * encodes meaning: green=financial-ready, gold=needs-review, blue=count,
 * navy=neutral.
 */
function KpiCard({
  accent = 'navy',
  icon,
  label,
  value,
  detail,
  className = '',
  ...props
}) {
  const classes = ['app-surface', 'app-surface--padded', 'app-kpi-card', `app-kpi-card--${accent}`, 'painel-kpi-card', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("div", _extends({
    className: classes
  }, props), icon ? /*#__PURE__*/React.createElement("div", {
    className: "painel-kpi-card__icon"
  }, icon) : null, /*#__PURE__*/React.createElement("div", {
    className: "painel-kpi-card__copy"
  }, /*#__PURE__*/React.createElement("div", {
    className: "app-kpi-card__label"
  }, label), /*#__PURE__*/React.createElement("div", {
    className: `app-kpi-card__value app-kpi-card__value--${accent}`
  }, value)), /*#__PURE__*/React.createElement("div", {
    className: "app-kpi-card__sub"
  }, detail ?? ''));
}
Object.assign(__ds_scope, { KpiCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/KpiCard.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Modal.jsx
try { (() => {
/**
 * Centered modal dialog with a navy header bar and a scrollable body. Backdrop
 * is a blurred dark scrim; click it or the × to dismiss. Renders nothing when
 * `open` is false.
 */
function Modal({
  open,
  onClose,
  title,
  width,
  children
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    className: "app-modal-backdrop",
    onMouseDown: e => e.target === e.currentTarget && onClose && onClose()
  }, /*#__PURE__*/React.createElement("div", {
    className: "app-modal",
    style: width ? {
      width
    } : undefined,
    role: "dialog",
    "aria-modal": "true"
  }, /*#__PURE__*/React.createElement("div", {
    className: "app-modal__header"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "app-modal__title"
  }, title), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "app-btn app-btn--ghost app-modal__close",
    onClick: onClose,
    "aria-label": "Fechar"
  }, "\u2715")), /*#__PURE__*/React.createElement("div", {
    className: "app-modal__body"
  }, children)));
}
Object.assign(__ds_scope, { Modal });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Modal.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
const TONE_LABEL = {
  success: '✓',
  error: '!',
  info: 'i'
};

/**
 * A single toast notification. Stack several inside a `.app-toast-stack`
 * fixed to the bottom-right. Three tones cover the product's feedback.
 */
function Toast({
  tone = 'info',
  children,
  onClose
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: `app-toast app-toast--${tone}`,
    role: "status"
  }, /*#__PURE__*/React.createElement("span", {
    className: "app-toast__icon",
    "aria-hidden": "true"
  }, TONE_LABEL[tone] || TONE_LABEL.info), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, children), onClose ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "app-toast__close",
    onClick: onClose,
    "aria-label": "Fechar"
  }, "\u2715") : null);
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/forms/Field.jsx
try { (() => {
/**
 * Labelled form field wrapper: an uppercase label over the control, with an
 * optional error line below. Wrap any Input/Select/Textarea.
 */
function Field({
  label,
  htmlFor,
  required = false,
  error,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "app-field"
  }, label ? /*#__PURE__*/React.createElement("label", {
    className: "app-field__label",
    htmlFor: htmlFor
  }, label, required ? /*#__PURE__*/React.createElement("span", {
    className: "app-field__required"
  }, " *") : null) : null, children, error ? /*#__PURE__*/React.createElement("div", {
    className: "app-field__error"
  }, error) : null);
}
Object.assign(__ds_scope, { Field });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Field.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Text input. Inherits the 44px control height, inset highlight, and blue
 * focus ring. Pass `full` to span its container.
 */
function Input({
  full = true,
  className = '',
  ...props
}) {
  const classes = ['app-input', full ? 'app-input--full' : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("input", _extends({
    className: classes
  }, props));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Native select styled to match Input, with a custom dual-chevron caret.
 */
function Select({
  full = true,
  className = '',
  children,
  ...props
}) {
  const classes = ['app-input', 'app-select', full ? 'app-input--full' : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("select", _extends({
    className: classes
  }, props), children);
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Textarea.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Multi-line text input. Vertically resizable, 112px minimum height.
 */
function Textarea({
  full = true,
  className = '',
  ...props
}) {
  const classes = ['app-input', 'app-textarea', full ? 'app-input--full' : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("textarea", _extends({
    className: classes
  }, props));
}
Object.assign(__ds_scope, { Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Textarea.jsx", error: String((e && e.message) || e) }); }

// components/navigation/FilterBar.jsx
try { (() => {
/**
 * Collapsible filter bar — a toggle row showing the active-filter count and a
 * Clear button, expanding to reveal a grid of fields. Wrap filter `Field`s as
 * children.
 */
function FilterBar({
  label = 'Filtros',
  activeCount = 0,
  defaultOpen = false,
  onClear,
  children
}) {
  const [open, setOpen] = React.useState(defaultOpen);
  return /*#__PURE__*/React.createElement("div", {
    className: `app-filter-bar${open ? ' app-filter-bar--open' : ''}`
  }, /*#__PURE__*/React.createElement("div", {
    className: "app-filter-bar__head"
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "app-filter-bar__toggle",
    onClick: () => setOpen(v => !v)
  }, /*#__PURE__*/React.createElement("span", {
    className: "app-filter-bar__chevron",
    "aria-hidden": "true"
  }, open ? '▾' : '▸'), label, activeCount > 0 ? /*#__PURE__*/React.createElement("span", {
    className: "app-filter-bar__count"
  }, activeCount) : null), activeCount > 0 && onClear ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "app-btn app-btn--ghost app-btn--sm app-filter-bar__clear",
    onClick: onClear
  }, "Limpar") : null), open ? /*#__PURE__*/React.createElement("div", {
    className: "app-filter-bar__body"
  }, children) : null);
}
Object.assign(__ds_scope, { FilterBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/FilterBar.jsx", error: String((e && e.message) || e) }); }

// components/navigation/TabButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * A single tab control. Two visual idioms exist in the product: standalone
 * pill tabs (default) and underline tabs (`underline`) used under a bottom
 * border. Toggle `active` for the selected state.
 */
function TabButton({
  active = false,
  underline = false,
  className = '',
  children,
  ...props
}) {
  const classes = underline ? ['tab-underline', active ? 'tab-underline--active' : '', className] : ['app-tab', active ? 'app-tab--active' : '', className];
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    className: classes.filter(Boolean).join(' ')
  }, props), children);
}
Object.assign(__ds_scope, { TabButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/TabButton.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * The fundamental bordered surface — a 1.5px-bordered white panel with an 8px
 * radius and no shadow. Pass `padded={false}` for flush content like tables.
 */
function Card({
  padded = true,
  className = '',
  children,
  ...props
}) {
  const classes = ['app-surface', padded ? 'app-surface--padded' : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("section", _extends({
    className: classes
  }, props), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/Card.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/EmptyState.jsx
try { (() => {
/**
 * Centered placeholder shown when a table or list has no rows. A bordered icon
 * tile over a title and optional description.
 */
function EmptyState({
  icon,
  title,
  description
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "app-empty-state"
  }, icon ? /*#__PURE__*/React.createElement("div", {
    className: "app-empty-state__icon"
  }, icon) : null, /*#__PURE__*/React.createElement("p", {
    className: "app-empty-state__title"
  }, title), description ? /*#__PURE__*/React.createElement("p", {
    className: "app-empty-state__description"
  }, description) : null);
}
Object.assign(__ds_scope, { EmptyState });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/EmptyState.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/InlineError.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Inline error band for form and data-load failures — soft red, bold, with a
 * leading alert icon slot.
 */
function InlineError({
  icon,
  message,
  children,
  className = '',
  ...props
}) {
  const classes = ['app-inline-error', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("div", _extends({
    className: classes
  }, props), icon, message ?? children);
}
Object.assign(__ds_scope, { InlineError });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/InlineError.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/PageHeader.jsx
try { (() => {
/**
 * The standard page title block: a Syne display heading with a 48px gold rule
 * beneath it, optional description, and a right-aligned action slot. Begins
 * every screen in the desk and portal.
 */
function PageHeader({
  title,
  description,
  action
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "page-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-header__copy"
  }, /*#__PURE__*/React.createElement("h1", {
    className: "page-header__title"
  }, title), description ? /*#__PURE__*/React.createElement("p", {
    className: "page-header__description"
  }, description) : null), action ? /*#__PURE__*/React.createElement("div", {
    className: "page-header__actions"
  }, action) : null);
}
Object.assign(__ds_scope, { PageHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/PageHeader.jsx", error: String((e && e.message) || e) }); }

// ui_kits/billing-portal/PortalBilling.jsx
try { (() => {
/* global React */
const Icon = window.Icon;
const LOCAL_STATUS = {
  paid: {
    tone: 'green',
    label: 'Pago'
  },
  partial: {
    tone: 'blue',
    label: 'Parcial'
  },
  overdue: {
    tone: 'yellow',
    label: 'Vencida'
  },
  issued: {
    tone: 'blue',
    label: 'Emitida'
  }
};
const DEM_STATUS = {
  paid: {
    tone: 'green',
    label: 'Pago'
  },
  overdue: {
    tone: 'red',
    label: 'Vencida'
  },
  issued: {
    tone: 'blue',
    label: 'Emitida'
  }
};
function fmtBl(bls) {
  if (bls.length <= 2) return bls.join(', ');
  return `${bls.slice(0, 2).join(', ')} +${bls.length - 2}`;
}
function PortalBilling({
  data,
  NS
}) {
  const {
    PageHeader,
    Card,
    Button,
    Badge,
    Field,
    Input,
    Select,
    FilterBar,
    MetricCard,
    Modal
  } = NS;
  const [tab, setTab] = React.useState('local');
  const [status, setStatus] = React.useState('');
  const [detail, setDetail] = React.useState(null);
  const localRows = data.local.filter(i => !status || i.status === status);
  const demRows = data.demurrage.filter(i => !status || i.status === status);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(PageHeader, {
    title: "Faturas",
    description: "Consulte suas faturas, pague via PIX e consolide B/Ls em aberto.",
    action: /*#__PURE__*/React.createElement(Button, null, /*#__PURE__*/React.createElement(Icon, {
      name: "file-plus-2",
      size: 16
    }), " Gerar fatura consolidada")
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 16,
      gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))',
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement(MetricCard, {
    label: "Saldo pendente",
    value: data.customer.pending
  }), /*#__PURE__*/React.createElement(MetricCard, {
    label: "Faturas emitidas",
    value: String(data.local.length)
  }), /*#__PURE__*/React.createElement(MetricCard, {
    label: "B/Ls eleg\xEDveis",
    value: "3"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      borderBottom: '1px solid var(--app-border)',
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: `tab-underline${tab === 'local' ? ' tab-underline--active' : ''}`,
    onClick: () => setTab('local')
  }, "Taxas Locais"), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: `tab-underline${tab === 'demurrage' ? ' tab-underline--active' : ''}`,
    onClick: () => setTab('demurrage')
  }, "Demurrage")), /*#__PURE__*/React.createElement(Card, {
    padded: false
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '16px 20px',
      borderBottom: '1px solid var(--app-border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 16,
      fontWeight: 700,
      color: 'var(--app-text-strong)'
    }
  }, tab === 'local' ? 'Faturas de taxas locais' : 'Sobreestadia de containers (D&D)'), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 4,
      fontSize: 13,
      color: 'var(--app-muted)'
    }
  }, tab === 'local' ? localRows.length : demRows.length, " fatura(s)")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '14px 20px 0'
    }
  }, /*#__PURE__*/React.createElement(FilterBar, {
    activeCount: status ? 1 : 0,
    defaultOpen: true,
    onClear: () => setStatus('')
  }, /*#__PURE__*/React.createElement("div", {
    className: "app-filter-grid"
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Status"
  }, /*#__PURE__*/React.createElement(Select, {
    value: status,
    onChange: e => setStatus(e.target.value)
  }, /*#__PURE__*/React.createElement("option", {
    value: ""
  }, "Todos"), /*#__PURE__*/React.createElement("option", {
    value: "issued"
  }, "Emitida"), /*#__PURE__*/React.createElement("option", {
    value: "paid"
  }, "Paga"), /*#__PURE__*/React.createElement("option", {
    value: "overdue"
  }, "Vencida"))), /*#__PURE__*/React.createElement(Field, {
    label: "Navio/Viagem"
  }, /*#__PURE__*/React.createElement(Input, {
    placeholder: "Digite o navio ou viagem"
  })), /*#__PURE__*/React.createElement(Field, {
    label: "B/L"
  }, /*#__PURE__*/React.createElement(Input, {
    placeholder: "N\xFAmero do B/L"
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Emiss\xE3o (de)"
  }, /*#__PURE__*/React.createElement(Input, {
    type: "date"
  }))))), /*#__PURE__*/React.createElement("div", {
    className: "app-table-scroll"
  }, tab === 'local' ? /*#__PURE__*/React.createElement("table", {
    className: "app-table app-table--compact",
    style: {
      minWidth: 760
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left'
    }
  }, "Fatura"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left'
    }
  }, "B/L"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left'
    }
  }, "Tipo"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left'
    }
  }, "Emiss\xE3o"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left'
    }
  }, "Total"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left'
    }
  }, "Status"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left'
    }
  }, "A\xE7\xE3o"))), /*#__PURE__*/React.createElement("tbody", null, localRows.map(inv => /*#__PURE__*/React.createElement("tr", {
    key: inv.id
  }, /*#__PURE__*/React.createElement("td", {
    style: {
      fontWeight: 700,
      color: 'var(--app-text-strong)'
    }
  }, inv.num), /*#__PURE__*/React.createElement("td", {
    className: "financial"
  }, fmtBl(inv.bls)), /*#__PURE__*/React.createElement("td", null, inv.type === 'consolidated' ? 'Consolidada' : 'Individual'), /*#__PURE__*/React.createElement("td", {
    className: "financial"
  }, inv.issued), /*#__PURE__*/React.createElement("td", {
    className: "financial",
    style: {
      fontWeight: 700,
      color: 'var(--app-text-strong)'
    }
  }, inv.total), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement(Badge, {
    tone: LOCAL_STATUS[inv.status].tone
  }, LOCAL_STATUS[inv.status].label)), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    onClick: () => setDetail(inv)
  }, "Detalhes")))))) : /*#__PURE__*/React.createElement("table", {
    className: "app-table app-table--compact",
    style: {
      minWidth: 820
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left'
    }
  }, "Documento"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left'
    }
  }, "BL / Trecho"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left'
    }
  }, "Emiss\xE3o"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left'
    }
  }, "Vencimento"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left'
    }
  }, "Total USD"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left'
    }
  }, "Total BRL"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left'
    }
  }, "Status"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left'
    }
  }, "A\xE7\xE3o"))), /*#__PURE__*/React.createElement("tbody", null, demRows.map(inv => /*#__PURE__*/React.createElement("tr", {
    key: inv.id
  }, /*#__PURE__*/React.createElement("td", {
    style: {
      fontWeight: 700,
      color: 'var(--app-text-strong)'
    }
  }, inv.num), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: "financial",
    style: {
      fontWeight: 600
    }
  }, inv.bl), " \xB7 ", inv.leg), /*#__PURE__*/React.createElement("td", {
    className: "financial"
  }, inv.issued), /*#__PURE__*/React.createElement("td", {
    className: "financial"
  }, inv.due), /*#__PURE__*/React.createElement("td", {
    className: "financial"
  }, inv.usd), /*#__PURE__*/React.createElement("td", {
    className: "financial",
    style: {
      fontWeight: 700,
      color: 'var(--app-text-strong)'
    }
  }, inv.brl), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement(Badge, {
    tone: DEM_STATUS[inv.status].tone
  }, DEM_STATUS[inv.status].label)), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    onClick: () => setDetail(inv)
  }, "Detalhes")))))))), /*#__PURE__*/React.createElement(Modal, {
    open: Boolean(detail),
    onClose: () => setDetail(null),
    title: `Fatura ${detail ? detail.num : ''}`
  }, detail ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "printer",
    size: 16
  }), " Imprimir PDF"), /*#__PURE__*/React.createElement(Button, {
    size: "sm"
  }, "Pagar via PIX")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 12,
      gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))'
    }
  }, /*#__PURE__*/React.createElement(MetricCard, {
    label: "Status",
    value: (LOCAL_STATUS[detail.status] || DEM_STATUS[detail.status]).label
  }), /*#__PURE__*/React.createElement(MetricCard, {
    label: "Total",
    value: detail.total || detail.brl
  }), /*#__PURE__*/React.createElement(MetricCard, {
    label: "Emiss\xE3o",
    value: detail.issued
  }), /*#__PURE__*/React.createElement(MetricCard, {
    label: "B/Ls",
    value: String(detail.bls ? detail.bls.length : 1)
  })), /*#__PURE__*/React.createElement(Card, {
    padded: false
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 16px',
      borderBottom: '1px solid var(--app-border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 700,
      color: 'var(--app-text-strong)'
    }
  }, "Itens cobrados"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--app-muted)',
      marginTop: 2
    }
  }, "Taxas, quantidades e valores")), /*#__PURE__*/React.createElement("div", {
    className: "app-table-scroll"
  }, /*#__PURE__*/React.createElement("table", {
    className: "app-table app-table--compact",
    style: {
      minWidth: 560
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left'
    }
  }, "Descri\xE7\xE3o"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left'
    }
  }, "B/L"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'right'
    }
  }, "Qtd"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'right'
    }
  }, "Valor unit."), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'right'
    }
  }, "Total"))), /*#__PURE__*/React.createElement("tbody", null, data.detail.items.map((it, i) => /*#__PURE__*/React.createElement("tr", {
    key: i
  }, /*#__PURE__*/React.createElement("td", null, it.desc), /*#__PURE__*/React.createElement("td", {
    className: "financial"
  }, it.bl), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'right'
    },
    className: "financial"
  }, it.qty), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'right'
    },
    className: "financial"
  }, it.unit), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'right',
      fontWeight: 700,
      color: 'var(--app-text-strong)'
    },
    className: "financial"
  }, it.total))))))), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 700,
      color: 'var(--app-text-strong)',
      marginBottom: 12
    }
  }, "Pagamento via PIX"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 18,
      alignItems: 'center',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 116,
      height: 116,
      borderRadius: 10,
      border: '1px solid var(--app-border)',
      background: 'repeating-conic-gradient(var(--app-navy) 0% 25%, #ffffff 0% 50%) 50% / 16px 16px'
    },
    "aria-label": "QR Code PIX"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--app-muted)',
      marginBottom: 4
    }
  }, "Copia e cola"), /*#__PURE__*/React.createElement("div", {
    className: "financial",
    style: {
      maxWidth: 280,
      wordBreak: 'break-all',
      borderRadius: 8,
      background: 'var(--app-surface-muted)',
      padding: 10,
      fontSize: 12
    }
  }, "00020126580014br.gov.bcb.pix0136a1b2c3d4-transhipping-520400005303986540", (detail.total || detail.brl).replace(/\D/g, ''), "5802BR6009SAO PAULO"))))) : null));
}
window.PortalBilling = PortalBilling;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/billing-portal/PortalBilling.jsx", error: String((e && e.message) || e) }); }

// ui_kits/billing-portal/data.js
try { (() => {
// Mock customer-portal data for the Transhipping billing portal. All fictional.
window.PORTAL_DATA = {
  customer: {
    name: 'Granito Serra Azul Ltda',
    cnpj: '12.345.678/0001-90',
    pending: 'R$ 27.340,00'
  },
  local: [{
    id: 3120,
    num: 'INV-3120',
    bls: ['MAEU7781234'],
    type: 'consolidated',
    issued: '02/06/2026',
    total: 'R$ 8.420,00',
    status: 'issued'
  }, {
    id: 3118,
    num: 'INV-3118',
    bls: ['MAEU7781190'],
    type: 'single',
    issued: '29/05/2026',
    total: 'R$ 4.260,00',
    status: 'overdue'
  }, {
    id: 3109,
    num: 'INV-3109',
    bls: ['MSKU8890021', 'MSKU8890022'],
    type: 'consolidated',
    issued: '24/05/2026',
    total: 'R$ 14.660,00',
    status: 'paid'
  }, {
    id: 3101,
    num: 'INV-3101',
    bls: ['MAEU7780041'],
    type: 'single',
    issued: '18/05/2026',
    total: 'R$ 3.980,00',
    status: 'paid'
  }],
  demurrage: [{
    id: 880,
    num: 'DEM-0880',
    bl: 'MAEU7781234',
    leg: 'CNSHA / BRSSZ',
    issued: '03/06/2026',
    due: '18/06/2026',
    usd: '$ 1.240,00',
    brl: 'R$ 6.720,00',
    status: 'issued'
  }, {
    id: 876,
    num: 'DEM-0876',
    bl: 'MSKU8890021',
    leg: 'CNNGB / BRRIG',
    issued: '27/05/2026',
    due: '11/06/2026',
    usd: '$ 2.180,00',
    brl: 'R$ 11.820,00',
    status: 'overdue'
  }, {
    id: 870,
    num: 'DEM-0870',
    bl: 'MAEU7780041',
    leg: 'CNSHA / BRSSZ',
    issued: '15/05/2026',
    due: '30/05/2026',
    usd: '$ 640,00',
    brl: 'R$ 3.470,00',
    status: 'paid'
  }],
  detail: {
    bls: [{
      bl: 'MAEU7781234',
      vessel: 'MSC Carolina / 512N',
      leg: 'CNSHA - BRSSZ',
      subtotal: 'R$ 8.420,00'
    }],
    items: [{
      desc: 'THC — Terminal Handling',
      bl: 'MAEU7781234',
      qty: 12,
      unit: 'R$ 480,00',
      total: 'R$ 5.760,00'
    }, {
      desc: 'Liberação documental (BL)',
      bl: 'MAEU7781234',
      qty: 1,
      unit: 'R$ 920,00',
      total: 'R$ 920,00'
    }, {
      desc: 'Taxa de desconsolidação',
      bl: 'MAEU7781234',
      qty: 1,
      unit: 'R$ 740,00',
      total: 'R$ 740,00'
    }, {
      desc: 'ISPS / Security',
      bl: 'MAEU7781234',
      qty: 12,
      unit: 'R$ 83,33',
      total: 'R$ 1.000,00'
    }]
  }
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/billing-portal/data.js", error: String((e && e.message) || e) }); }

// ui_kits/operational-desk/AppChrome.jsx
try { (() => {
/* global React */
// App chrome: dark market strip, navy header, gold-ruled nav. Uses DS CSS classes.
const Icon = window.Icon;
function MarketStrip({
  user,
  rates,
  alerts
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "app-market-strip"
  }, /*#__PURE__*/React.createElement("div", {
    className: "app-market-strip__content"
  }, /*#__PURE__*/React.createElement("div", {
    className: "app-market-strip__left"
  }, /*#__PURE__*/React.createElement("button", {
    className: "hib-alert-btn",
    type: "button"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "alert-triangle",
    size: 11
  }), alerts.demurrage, " demurrages vencidos"), /*#__PURE__*/React.createElement("span", {
    className: "hib-sep"
  }, "\xB7"), /*#__PURE__*/React.createElement("button", {
    className: "hib-alert-btn",
    type: "button"
  }, alerts.granite, " Granite pendente")), /*#__PURE__*/React.createElement("div", {
    className: "app-market-strip__center"
  }, /*#__PURE__*/React.createElement("span", {
    className: "hib-currency-label"
  }, "USD"), /*#__PURE__*/React.createElement("span", {
    className: "hib-currency-value"
  }, "R$ ", rates.usd), /*#__PURE__*/React.createElement("span", {
    className: "hib-sep"
  }, "\xB7"), /*#__PURE__*/React.createElement("span", {
    className: "hib-currency-label"
  }, "CNY"), /*#__PURE__*/React.createElement("span", {
    className: "hib-currency-value"
  }, "R$ ", rates.cny)), /*#__PURE__*/React.createElement("div", {
    className: "app-market-strip__right"
  }, /*#__PURE__*/React.createElement("button", {
    className: "hib-user-btn",
    type: "button"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "user-circle",
    size: 13
  }), /*#__PURE__*/React.createElement("span", {
    className: "hib-user-name"
  }, user.name), /*#__PURE__*/React.createElement("span", {
    className: "hib-sep"
  }, "\xB7"), /*#__PURE__*/React.createElement("span", {
    className: "hib-user-role"
  }, user.role)))));
}
const NAV = [{
  id: 'painel',
  label: 'Painel',
  icon: 'home'
}, {
  id: 'viagens',
  label: 'Viagens',
  icon: 'ship'
}, {
  id: 'importacao',
  label: 'Importação',
  icon: 'file-spreadsheet',
  dropdown: true
}, {
  id: 'exportacao',
  label: 'Exportação',
  icon: 'package',
  dropdown: true
}, {
  id: 'clientes',
  label: 'Clientes',
  icon: 'users'
}, {
  id: 'alertas',
  label: 'Alertas',
  icon: 'bell',
  badge: 5
}, {
  id: 'faturamento',
  label: 'Financeiro',
  icon: 'dollar-sign',
  dropdown: true,
  alert: true
}];
function AppChrome({
  user,
  rates,
  alerts,
  active,
  onNavigate,
  onSignOut
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(MarketStrip, {
    user: user,
    rates: rates,
    alerts: alerts
  }), /*#__PURE__*/React.createElement("header", {
    className: "app-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "app-header__content"
  }, /*#__PURE__*/React.createElement("button", {
    className: "app-header__brand",
    type: "button",
    onClick: () => onNavigate('painel')
  }, /*#__PURE__*/React.createElement("img", {
    className: "app-header__brand-logo",
    src: "assets/logo-white.png",
    alt: "Transhipping"
  }), /*#__PURE__*/React.createElement("div", {
    className: "app-header__titles"
  }, /*#__PURE__*/React.createElement("div", {
    className: "app-header__eyebrow"
  }, "Desk operacional"), /*#__PURE__*/React.createElement("div", {
    className: "app-header__subtitle"
  }, "importa\xE7\xE3o, exporta\xE7\xE3o e faturamento"))), /*#__PURE__*/React.createElement("div", {
    className: "app-header__actions"
  }, /*#__PURE__*/React.createElement("div", {
    className: "app-user-pill"
  }, /*#__PURE__*/React.createElement("span", {
    className: "app-user-pill__icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "user",
    size: 14
  })), /*#__PURE__*/React.createElement("span", {
    className: "app-user-pill__name"
  }, user.name)), /*#__PURE__*/React.createElement("button", {
    className: "app-btn app-btn--ghost app-header__logout",
    type: "button",
    onClick: onSignOut
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "log-out",
    size: 16
  }), " Sair")))), /*#__PURE__*/React.createElement("div", {
    className: "app-nav-bar"
  }, /*#__PURE__*/React.createElement("nav", {
    className: "app-nav-scroll"
  }, NAV.map(item => {
    const isActive = active === item.id || item.id === 'faturamento' && active === 'faturamento';
    return /*#__PURE__*/React.createElement("button", {
      key: item.id,
      type: "button",
      className: `app-nav-link app-nav-link--button${isActive ? ' active' : ''}`,
      onClick: () => onNavigate(item.id === 'importacao' || item.id === 'exportacao' ? active : item.id)
    }, /*#__PURE__*/React.createElement(Icon, {
      name: item.icon,
      size: 18
    }), item.label, item.badge ? /*#__PURE__*/React.createElement("span", {
      className: "app-nav-badge"
    }, item.badge) : null, item.alert ? /*#__PURE__*/React.createElement("span", {
      className: "app-nav-alert-dot"
    }) : null, item.dropdown ? /*#__PURE__*/React.createElement(Icon, {
      name: "chevron-down",
      size: 16,
      className: "app-nav-dropdown__chevron"
    }) : null);
  }))));
}
window.AppChrome = AppChrome;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/operational-desk/AppChrome.jsx", error: String((e && e.message) || e) }); }

// ui_kits/operational-desk/FaturamentoScreen.jsx
try { (() => {
/* global React */
const Icon = window.Icon;
const INV_STATUS = {
  paid: {
    tone: 'green',
    label: 'Paga'
  },
  partial: {
    tone: 'blue',
    label: 'Parcial'
  },
  overdue: {
    tone: 'red',
    label: 'Vencida'
  },
  issued: {
    tone: 'blue',
    label: 'Emitida'
  }
};
function FaturamentoScreen({
  data,
  NS
}) {
  const {
    PageHeader,
    Card,
    Button,
    Badge,
    Field,
    Input,
    Select,
    FilterBar,
    MetricCard,
    Modal
  } = NS;
  const [status, setStatus] = React.useState('');
  const [query, setQuery] = React.useState('');
  const [selected, setSelected] = React.useState(null);
  const rows = data.invoices.filter(i => (!status || i.status === status) && (!query || i.customer.toLowerCase().includes(query.toLowerCase()) || i.num.toLowerCase().includes(query.toLowerCase())));
  const activeCount = (status ? 1 : 0) + (query ? 1 : 0);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(PageHeader, {
    title: "Faturamento",
    description: "Faturas de taxas locais emitidas para os clientes, com situa\xE7\xE3o financeira e status de pagamento.",
    action: /*#__PURE__*/React.createElement(Button, null, /*#__PURE__*/React.createElement(Icon, {
      name: "file-plus-2",
      size: 16
    }), " Gerar fatura consolidada")
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 16,
      gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement(MetricCard, {
    label: "Total faturado (m\xEAs)",
    value: "R$ 243.180,00"
  }), /*#__PURE__*/React.createElement(MetricCard, {
    label: "Recebido",
    value: "R$ 161.080,00"
  }), /*#__PURE__*/React.createElement(MetricCard, {
    label: "Em aberto",
    value: "R$ 82.100,00"
  }), /*#__PURE__*/React.createElement(MetricCard, {
    label: "Faturas vencidas",
    value: "1"
  })), /*#__PURE__*/React.createElement(FilterBar, {
    activeCount: activeCount,
    defaultOpen: true,
    onClear: () => {
      setStatus('');
      setQuery('');
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "app-filter-grid"
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Buscar"
  }, /*#__PURE__*/React.createElement(Input, {
    placeholder: "Cliente ou n\xBA da fatura",
    value: query,
    onChange: e => setQuery(e.target.value)
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Status"
  }, /*#__PURE__*/React.createElement(Select, {
    value: status,
    onChange: e => setStatus(e.target.value)
  }, /*#__PURE__*/React.createElement("option", {
    value: ""
  }, "Todos"), /*#__PURE__*/React.createElement("option", {
    value: "issued"
  }, "Emitida"), /*#__PURE__*/React.createElement("option", {
    value: "partial"
  }, "Parcial"), /*#__PURE__*/React.createElement("option", {
    value: "paid"
  }, "Paga"), /*#__PURE__*/React.createElement("option", {
    value: "overdue"
  }, "Vencida"))), /*#__PURE__*/React.createElement(Field, {
    label: "POD"
  }, /*#__PURE__*/React.createElement(Select, null, /*#__PURE__*/React.createElement("option", null, "Todos"), /*#__PURE__*/React.createElement("option", null, "BRSSZ"), /*#__PURE__*/React.createElement("option", null, "BRRIG"))), /*#__PURE__*/React.createElement(Field, {
    label: "Emiss\xE3o (de)"
  }, /*#__PURE__*/React.createElement(Input, {
    type: "date"
  })))), /*#__PURE__*/React.createElement(Card, {
    padded: false
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 8,
      padding: '14px 16px',
      borderBottom: '1px solid var(--app-border)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 700,
      color: 'var(--app-text-strong)'
    }
  }, rows.length, " fatura(s) retornada(s)"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'var(--app-muted)'
    }
  }, "Ordenado por emiss\xE3o (recente)")), /*#__PURE__*/React.createElement("div", {
    className: "app-table-scroll"
  }, /*#__PURE__*/React.createElement("table", {
    className: "app-table app-table--compact",
    style: {
      minWidth: 1080
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left'
    }
  }, "Fatura"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left'
    }
  }, "B/L"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left'
    }
  }, "Tipo"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left'
    }
  }, "Navio / Viagem \xB7 POD"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left'
    }
  }, "Emiss\xE3o"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left'
    }
  }, "Financeiro"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left'
    }
  }, "Status"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left'
    }
  }, "A\xE7\xF5es"))), /*#__PURE__*/React.createElement("tbody", null, rows.map(inv => /*#__PURE__*/React.createElement("tr", {
    key: inv.id
  }, /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      color: 'var(--app-text-strong)'
    }
  }, inv.num), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--app-muted)'
    }
  }, inv.customer), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--app-muted-soft)'
    },
    className: "financial"
  }, inv.cnpj)), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 700,
      color: 'var(--app-blue)'
    }
  }, inv.bls[0]), /*#__PURE__*/React.createElement(Badge, {
    tone: inv.type === 'consolidated' ? 'blue' : 'slate'
  }, inv.bls.length, " B/L", inv.bls.length > 1 ? 's' : ''))), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement(Badge, {
    tone: inv.type === 'consolidated' ? 'blue' : 'slate'
  }, inv.type === 'consolidated' ? 'Consolidada' : 'Único BL')), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600
    }
  }, inv.vessel), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--app-muted)'
    }
  }, "POD ", inv.pod)), /*#__PURE__*/React.createElement("td", {
    className: "financial"
  }, inv.issued), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
    className: "financial",
    style: {
      fontWeight: 700,
      color: 'var(--app-text-strong)'
    }
  }, "Total ", inv.total), /*#__PURE__*/React.createElement("div", {
    className: "financial",
    style: {
      fontSize: 12,
      color: 'var(--app-muted)'
    }
  }, "Saldo ", inv.balance)), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement(Badge, {
    tone: INV_STATUS[inv.status].tone
  }, INV_STATUS[inv.status].label)), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    onClick: () => setSelected(inv)
  }, "Detalhes"))))))), /*#__PURE__*/React.createElement("div", {
    className: "app-table__footer"
  }, /*#__PURE__*/React.createElement("span", null, "P\xE1gina 1 de 1 \xB7 ", rows.length, " registros"), /*#__PURE__*/React.createElement("div", {
    className: "app-table__footer-controls"
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    disabled: true
  }, "Anterior"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    disabled: true
  }, "Pr\xF3xima")))), /*#__PURE__*/React.createElement(Modal, {
    open: Boolean(selected),
    onClose: () => setSelected(null),
    title: `Fatura ${selected ? selected.num : ''}`
  }, selected ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: 10,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "rotate-ccw",
    size: 16
  }), " Refazer consolidada"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "printer",
    size: 16
  }), " Imprimir PDF")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 12,
      gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))'
    }
  }, /*#__PURE__*/React.createElement(MetricCard, {
    label: "Status",
    value: INV_STATUS[selected.status].label
  }), /*#__PURE__*/React.createElement(MetricCard, {
    label: "Total",
    value: selected.total
  }), /*#__PURE__*/React.createElement(MetricCard, {
    label: "Pago",
    value: selected.paid
  }), /*#__PURE__*/React.createElement(MetricCard, {
    label: "Saldo",
    value: selected.balance
  }), /*#__PURE__*/React.createElement(MetricCard, {
    label: "B/Ls",
    value: String(selected.bls.length)
  })), /*#__PURE__*/React.createElement(Card, {
    padded: false
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 16px',
      borderBottom: '1px solid var(--app-border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 700,
      color: 'var(--app-text-strong)'
    }
  }, "Itens cobrados"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--app-muted)',
      marginTop: 2
    }
  }, "Taxas, quantidades e valores")), /*#__PURE__*/React.createElement("div", {
    className: "app-table-scroll"
  }, /*#__PURE__*/React.createElement("table", {
    className: "app-table app-table--compact",
    style: {
      minWidth: 560
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left'
    }
  }, "Descri\xE7\xE3o"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left'
    }
  }, "B/L"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'right'
    }
  }, "Qtd"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'right'
    }
  }, "Valor unit."), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'right'
    }
  }, "Total"))), /*#__PURE__*/React.createElement("tbody", null, data.invoiceItems.map((it, i) => /*#__PURE__*/React.createElement("tr", {
    key: i
  }, /*#__PURE__*/React.createElement("td", null, it.desc), /*#__PURE__*/React.createElement("td", {
    className: "financial"
  }, it.bl), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'right'
    },
    className: "financial"
  }, it.qty), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'right'
    },
    className: "financial"
  }, it.unit), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'right',
      fontWeight: 700,
      color: 'var(--app-text-strong)'
    },
    className: "financial"
  }, it.total)))))))) : null));
}
window.FaturamentoScreen = FaturamentoScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/operational-desk/FaturamentoScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/operational-desk/Icon.jsx
try { (() => {
/* global React */
// Lucide icon → clean inline SVG (uses copied lucide icon data, no hand-drawing).
const ICON_ALIAS = {
  ship: 'Ship',
  home: 'Home',
  users: 'Users',
  bell: 'Bell',
  'file-spreadsheet': 'FileSpreadsheet',
  package: 'Package',
  'dollar-sign': 'DollarSign',
  boxes: 'Boxes',
  'alert-triangle': 'AlertTriangle',
  receipt: 'Receipt',
  'file-text': 'FileText',
  monitor: 'Monitor',
  'refresh-cw': 'RefreshCw',
  'check-circle': 'CheckCircle',
  'user-x': 'UserX',
  'receipt-text': 'ReceiptText',
  'chevron-down': 'ChevronDown',
  user: 'User',
  'log-out': 'LogOut',
  'building-2': 'Building2',
  'file-plus-2': 'FilePlus2',
  printer: 'Printer',
  'rotate-ccw': 'RotateCcw',
  x: 'X',
  'user-circle': 'UserCircle',
  inbox: 'Inbox',
  search: 'Search',
  'table-properties': 'TableProperties',
  mountain: 'Mountain',
  clock: 'Clock',
  car: 'Car',
  'alert-circle': 'AlertCircle'
};
function Icon({
  name,
  size = 16,
  strokeWidth = 2,
  style,
  className
}) {
  const key = ICON_ALIAS[name] || name;
  const node = window.lucide && window.lucide.icons && window.lucide.icons[key] || null;
  if (!node) {
    return /*#__PURE__*/React.createElement("svg", {
      width: size,
      height: size,
      viewBox: "0 0 24 24",
      style: style,
      className: className
    });
  }
  // Lucide stores each icon as ["svg", {attrs}, [ [tag, {geom}], ... ]] — children are node[2].
  const childNodes = Array.isArray(node) && Array.isArray(node[2]) ? node[2] : [];
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: strokeWidth,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: style,
    className: className,
    "aria-hidden": "true"
  }, childNodes.map(([tag, attrs], i) => React.createElement(tag, {
    key: i,
    ...attrs
  })));
}
window.Icon = Icon;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/operational-desk/Icon.jsx", error: String((e && e.message) || e) }); }

// ui_kits/operational-desk/PainelScreen.jsx
try { (() => {
/* global React */
const Icon = window.Icon;
const CE_TONE = {
  approved: 'green',
  received: 'blue',
  launching: 'yellow',
  partial: 'yellow',
  waiting: 'slate'
};
const CE_LABEL = {
  approved: 'Aprovado',
  received: 'Recebido',
  launching: 'Lançando',
  partial: 'Parcial',
  waiting: 'Aguardando'
};
function LineUpTable({
  rows
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "app-table-scroll"
  }, /*#__PURE__*/React.createElement("table", {
    className: "app-table app-table--dense",
    style: {
      minWidth: 980
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'left'
    }
  }, "Vessel"), /*#__PURE__*/React.createElement("th", null, "Voy"), /*#__PURE__*/React.createElement("th", null, "POD"), /*#__PURE__*/React.createElement("th", null, "ETA"), /*#__PURE__*/React.createElement("th", null, "ETB"), /*#__PURE__*/React.createElement("th", null, "VIN"), /*#__PURE__*/React.createElement("th", null, "CAR"), /*#__PURE__*/React.createElement("th", null, "CG"), /*#__PURE__*/React.createElement("th", null, "Total"), /*#__PURE__*/React.createElement("th", null, "MTY"), /*#__PURE__*/React.createElement("th", null, "RTW"), /*#__PURE__*/React.createElement("th", null, "CEs"), /*#__PURE__*/React.createElement("th", null, "Linked"))), /*#__PURE__*/React.createElement("tbody", null, rows.map(r => /*#__PURE__*/React.createElement("tr", {
    key: r.vessel + r.voy
  }, /*#__PURE__*/React.createElement("td", {
    style: {
      fontWeight: 700,
      color: 'var(--app-text-strong)'
    }
  }, r.vessel), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'center',
      fontWeight: 600
    }
  }, r.voy), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'center',
      fontWeight: 700,
      color: 'var(--app-blue)'
    }
  }, r.pod), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'center'
    }
  }, r.eta), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'center'
    }
  }, r.etb), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'center'
    },
    className: "financial"
  }, r.vin), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'center'
    },
    className: "financial"
  }, r.car), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'center'
    },
    className: "financial"
  }, r.cg), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'center',
      fontWeight: 700,
      color: 'var(--app-blue)'
    },
    className: "financial"
  }, r.total), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'center'
    },
    className: "financial"
  }, r.mty), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'center'
    },
    className: "financial"
  }, r.rtw === null ? '–' : r.rtw), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: `app-badge app-badge--${CE_TONE[r.ce]}`
  }, CE_LABEL[r.ce])), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: `app-badge app-badge--${r.linked ? 'green' : 'yellow'}`
  }, r.linked ? 'SIM' : 'NÃO')))))));
}
function PainelScreen({
  data,
  NS
}) {
  const {
    PageHeader,
    Card,
    KpiCard,
    Button,
    Badge
  } = NS;
  const [filter, setFilter] = React.useState('all');
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(PageHeader, {
    title: "Painel",
    description: "KPIs operacionais e quadro Line Up consolidados na p\xE1gina principal do sistema.",
    action: /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        flexWrap: 'wrap'
      }
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      size: "sm"
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "monitor",
      size: 14
    }), " Abrir tela TV"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12,
        color: 'var(--app-muted)'
      }
    }, "Atualizado: 09:12:44"), /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      size: "sm"
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "refresh-cw",
      size: 14
    }), " Atualizar"))
  }), /*#__PURE__*/React.createElement(Card, {
    padded: false,
    style: {
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      justifyContent: 'space-between',
      gap: 16,
      padding: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 8
    }
  }, [['all', 'Todas as escalas'], ['active', 'Escalas ativas'], ['completed', 'Concluídas']].map(([id, label]) => /*#__PURE__*/React.createElement("button", {
    key: id,
    type: "button",
    className: `app-tab${filter === id ? ' app-tab--active' : ''}`,
    onClick: () => setFilter(id)
  }, label))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "blue"
  }, "ETB vinculado ao POD"), /*#__PURE__*/React.createElement(Badge, {
    tone: "green"
  }, "ATD remove a rota"), /*#__PURE__*/React.createElement(Badge, {
    tone: "slate"
  }, "Tela TV: /line-up-tv"))), /*#__PURE__*/React.createElement(LineUpTable, {
    rows: data.lineup
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      borderTop: '1px solid var(--app-border)',
      padding: '10px 16px',
      margin: 0,
      fontSize: 11,
      color: 'var(--app-muted)'
    }
  }, "VIN = ve\xEDculos (ro-ro) \xB7 CAR = carros em container \xB7 CG = carga geral \xB7 MTY = vazios \xB7 RTW = restow \xB7 CEs = status dos CEs Mercante \xB7 Linked = manifesto vinculado")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 16,
      gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))',
      marginTop: 28
    }
  }, data.kpis.map(k => /*#__PURE__*/React.createElement(KpiCard, {
    key: k.label,
    accent: k.accent,
    label: k.label,
    value: k.value,
    detail: k.detail
  }))));
}
window.PainelScreen = PainelScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/operational-desk/PainelScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/operational-desk/data.js
try { (() => {
// Mock operational data for the Transhipping Desk UI kit. All fictional.
window.DESK_DATA = {
  user: {
    name: 'Ana Duarte',
    role: 'Operações'
  },
  rates: {
    usd: '5,4210',
    cny: '0,7480'
  },
  alerts: {
    demurrage: 2,
    granite: 1
  },
  kpis: [{
    accent: 'navy',
    label: 'B/Ls ativos',
    value: '142',
    detail: ''
  }, {
    accent: 'blue',
    label: 'Containers distintos',
    value: '3.480',
    detail: ''
  }, {
    accent: 'gold',
    label: 'Aguardando revisão',
    value: '7',
    detail: 'Ver em Revisão'
  }, {
    accent: 'green',
    label: 'Faturas em aberto',
    value: '18',
    detail: 'R$ 243.000,00'
  }, {
    accent: 'gold',
    label: 'Taxas para revisar',
    value: '4',
    detail: ''
  }, {
    accent: 'green',
    label: 'Prontos para faturar',
    value: '11',
    detail: ''
  }, {
    accent: 'navy',
    label: 'B/Ls sem cliente',
    value: '3',
    detail: 'Vincular em Revisão'
  }, {
    accent: 'navy',
    label: 'Vazios IMP (MTY)',
    value: '612',
    detail: ''
  }],
  lineup: [{
    vessel: 'MSC Carolina',
    voy: '512N',
    pod: 'BRSSZ',
    eta: '12/06',
    etb: '13/06',
    vin: 0,
    car: 18,
    cg: 240,
    total: 612,
    mty: 88,
    rtw: 4,
    ce: 'approved',
    linked: true
  }, {
    vessel: 'Maersk Brani',
    voy: '233S',
    pod: 'BRRIG',
    eta: '13/06',
    etb: '14/06',
    vin: 320,
    car: 0,
    cg: 96,
    total: 540,
    mty: 124,
    rtw: 0,
    ce: 'launching',
    linked: true
  }, {
    vessel: 'CMA CGM Itajaí',
    voy: '118N',
    pod: 'BRPNG',
    eta: '14/06',
    etb: '15/06',
    vin: 0,
    car: 42,
    cg: 410,
    total: 730,
    mty: 156,
    rtw: 12,
    ce: 'received',
    linked: false
  }, {
    vessel: 'Log-In Pantanal',
    voy: '907N',
    pod: 'BRSSZ',
    eta: '15/06',
    etb: '16/06',
    vin: 0,
    car: 0,
    cg: 188,
    total: 320,
    mty: 60,
    rtw: null,
    ce: 'waiting',
    linked: false
  }, {
    vessel: 'Aliança Brasil',
    voy: '441S',
    pod: 'BRIOA',
    eta: '16/06',
    etb: '17/06',
    vin: 210,
    car: 8,
    cg: 64,
    total: 398,
    mty: 92,
    rtw: 0,
    ce: 'partial',
    linked: true
  }, {
    vessel: 'Hapag Rio',
    voy: '076N',
    pod: 'BRVIX',
    eta: '17/06',
    etb: '18/06',
    vin: 0,
    car: 26,
    cg: 302,
    total: 588,
    mty: 110,
    rtw: 6,
    ce: 'approved',
    linked: true
  }],
  invoices: [{
    id: 2048,
    num: 'INV-2048',
    bls: ['MAEU7781234'],
    customer: 'Granito Serra Azul Ltda',
    cnpj: '12.345.678/0001-90',
    vessel: 'MSC Carolina · 512N',
    pod: 'BRSSZ',
    issued: '02/06/2026',
    total: 'R$ 8.420,00',
    paid: 'R$ 5.000,00',
    balance: 'R$ 3.420,00',
    status: 'partial',
    type: 'single'
  }, {
    id: 2047,
    num: 'INV-2047',
    bls: ['CMAU2210019', 'CMAU2210020'],
    customer: 'Itajaí Importações S.A.',
    cnpj: '98.765.432/0001-10',
    vessel: 'CMA CGM Itajaí · 118N',
    pod: 'BRPNG',
    issued: '01/06/2026',
    total: 'R$ 23.180,00',
    paid: 'R$ 23.180,00',
    balance: 'R$ 0,00',
    status: 'paid',
    type: 'consolidated'
  }, {
    id: 2046,
    num: 'INV-2046',
    bls: ['MSKU8890021'],
    customer: 'Vale Verde Comércio',
    cnpj: '45.111.222/0001-33',
    vessel: 'Maersk Brani · 233S',
    pod: 'BRRIG',
    issued: '28/05/2026',
    total: 'R$ 5.640,00',
    paid: 'R$ 0,00',
    balance: 'R$ 5.640,00',
    status: 'overdue',
    type: 'single'
  }, {
    id: 2045,
    num: 'INV-2045',
    bls: ['HLCU3320088'],
    customer: 'Porto Real Logística',
    cnpj: '33.999.888/0001-77',
    vessel: 'Hapag Rio · 076N',
    pod: 'BRVIX',
    issued: '27/05/2026',
    total: 'R$ 12.900,00',
    paid: 'R$ 12.900,00',
    balance: 'R$ 0,00',
    status: 'paid',
    type: 'single'
  }, {
    id: 2044,
    num: 'INV-2044',
    bls: ['ALBR4410055', 'ALBR4410056', 'ALBR4410057'],
    customer: 'Aliança Cargas do Sul',
    cnpj: '21.444.555/0001-22',
    vessel: 'Aliança Brasil · 441S',
    pod: 'BRIOA',
    issued: '26/05/2026',
    total: 'R$ 41.700,00',
    paid: 'R$ 20.000,00',
    balance: 'R$ 21.700,00',
    status: 'issued',
    type: 'consolidated'
  }],
  invoiceItems: [{
    desc: 'THC — Terminal Handling',
    bl: 'MAEU7781234',
    qty: 12,
    unit: 'R$ 480,00',
    total: 'R$ 5.760,00'
  }, {
    desc: 'Liberação documental (BL)',
    bl: 'MAEU7781234',
    qty: 1,
    unit: 'R$ 920,00',
    total: 'R$ 920,00'
  }, {
    desc: 'Taxa de desconsolidação',
    bl: 'MAEU7781234',
    qty: 1,
    unit: 'R$ 740,00',
    total: 'R$ 740,00'
  }, {
    desc: 'ISPS / Security',
    bl: 'MAEU7781234',
    qty: 12,
    unit: 'R$ 83,33',
    total: 'R$ 1.000,00'
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/operational-desk/data.js", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Callout = __ds_scope.Callout;

__ds_ns.MetricCard = __ds_scope.MetricCard;

__ds_ns.KpiCard = __ds_scope.KpiCard;

__ds_ns.Modal = __ds_scope.Modal;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Field = __ds_scope.Field;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Textarea = __ds_scope.Textarea;

__ds_ns.FilterBar = __ds_scope.FilterBar;

__ds_ns.TabButton = __ds_scope.TabButton;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.EmptyState = __ds_scope.EmptyState;

__ds_ns.InlineError = __ds_scope.InlineError;

__ds_ns.PageHeader = __ds_scope.PageHeader;

})();
