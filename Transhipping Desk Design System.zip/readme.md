# Transhipping Desk — Design System

A design system for **Transhipping · Agenciamento Marítimo**, a Brazilian
maritime-agency operations platform. The product is an internal operational
**desk** plus an external customer **portal**, covering vessel line-up, manifests
& EDIs (Baplie, CE Mercante), container/cargo tracking, local-fee invoicing,
demurrage (D&D) and PIX reconciliation. The interface language is **Brazilian
Portuguese** and the domain is dense, tabular and financial.

> **Sources.** Built from the product source at
> `github.com/luccafwlog/transhipping-desk2` (private) — primarily `src/index.css`
> (the canonical token + class system), `src/components/layout/*`,
> `src/components/ui/*`, `src/components/billing/*`, `src/components/lineup/*` and
> `src/pages/*`. Explore that repo for deeper fidelity when building new screens.

---

## Index / manifest

**Foundations**
- `styles.css` — the single entry point consumers link. `@import`s only.
- `tokens/base.css` — reset + body (warm-paper bg, dot grid).
- `tokens/colors.css` — color tokens (light = canonical; `data-visual-theme='dark'` opt-in).
- `tokens/typography.css` — Syne / DM Sans / IBM Plex Mono + scale.
- `tokens/spacing.css` — spacing, radius, control sizing, shadows.
- `tokens/components.css` — component classes (`app-btn`, `app-table`, `app-badge`, …).
- `tokens/chrome.css` — app shell: market strip, header, nav, auth.
- `guidelines/*.card.html` — foundation specimen cards (Colors, Type, Spacing, Brand).

**Components** (`window.TranshippingDeskDesignSystem_64fdac`)
- `components/core/` — Button, Badge, MetricCard, Callout
- `components/surfaces/` — Card, PageHeader, EmptyState, InlineError
- `components/forms/` — Field, Input, Select, Textarea
- `components/navigation/` — TabButton, FilterBar
- `components/feedback/` — Modal, Toast
- `components/data/` — KpiCard

**UI kits**
- `ui_kits/operational-desk/` — internal desk: Login, Painel (Line Up + KPIs), Faturamento.
- `ui_kits/billing-portal/` — customer portal: Faturas (Taxas Locais / Demurrage) + PIX.

**Assets** — `assets/` (logos: navy, reversed-white, favicon, app icon).

---

## Content fundamentals

- **Language:** Brazilian Portuguese throughout. Domain abbreviations are used
  bare and uppercase: **B/L** (conhecimento de embarque), **POD/POL**, **ETA/ETB/ATD**,
  **CE Mercante**, **THC**, **MTY** (vazios), **VIN/CAR/CG/RTW/BB**, **D&D / Demurrage**,
  **PTAX**, **PIX**, **CNPJ/CPF**.
- **Voice:** terse, operational, third-person/imperative. UI strings are short
  commands or labels — "Gerar fatura consolidada", "Atualizar", "Abrir tela TV",
  "Vincular em Revisão", "Entre com as credenciais provisionadas pelo administrador."
- **Casing:** sentence case for descriptions and buttons; **UPPERCASE** for eyebrows,
  table headers, field labels and badges. Titles are short nouns ("Painel",
  "Faturamento", "Faturas").
- **Status vocabulary:** Emitida · Parcial · Paga · Vencida · Cancelada · Obsoleta ·
  Aguardando · Aprovado · Recebido · Lançando. Yes/No render as **SIM / NÃO**.
- **Numbers:** pt-BR formatting — `R$ 8.420,00`, `$ 1.240,00`, dates `dd/mm/aaaa`,
  FX to 4 decimals (`R$ 5,4210`). All figures set in the monospaced face.
- **No emoji.** Tone is a professional instrument, not a marketing site.

## Visual foundations

- **Palette.** Deep **navy** (`#152238`) is the structural brand — header, nav,
  table heads, modal headers, auth panel. A single **gold** accent (`#d4882e`) is the
  operational signature: the 2px nav underline rule, the 48px rule under page titles,
  badges and alert dots. Backgrounds are **warm paper** (`#f4f1ea`) with a subtle
  radial **dot grid** (1px dots, 20px pitch); surfaces are pure white.
- **Semantic signals.** blue = info/issued, green = paid/ready, amber = review/warning,
  red = overdue/danger — each as a saturated fill plus a soft tint for badge fills.
- **Type.** **Syne** (700/800, tracking −0.04em) for display titles & modal headers;
  **DM Sans** (400–600) for all body/UI; **IBM Plex Mono** for every number, money and
  code-like value so columns align. Eyebrows are 11px uppercase, tracked 0.10–0.12em.
- **Shape & depth.** 8px default radius (16px modals, 999px pills). Elevation is
  deliberately **near-flat** — surfaces are defined by **1.5px borders**, not shadows.
  Shadows appear only on modals, toasts and floating menus.
- **Tables** are the heart of the product: navy heads with uppercase tracked labels,
  1px row dividers, zebra at ~2% navy, blue hover wash, compact/dense paddings. Money
  cells use the mono face. Horizontal scroll wrappers (`app-table-scroll`) for wide grids.
- **Chrome** stacks three bands: darkest market strip (alerts · FX · user) → navy
  header (reversed logo + user pill) → navy-2 nav with the gold bottom rule and an
  inset-gold active underline.
- **Motion.** Restrained: 0.18s ease on color/border/shadow for hovers and focus.
  No bounces, no decorative loops. Focus = 4px soft-blue ring. Hover on secondary
  controls shifts toward blue; buttons darken ~18% on press.
- **Backdrops.** Modal scrim is a blurred dark wash (`rgba(8,15,25,0.54)` + 12px blur).
  The auth and chrome bands carry a faint gold/white dot texture.

## Iconography

The product uses **[Lucide](https://lucide.dev)** (`lucide-react` in source) at
1.5–2px stroke, sizes 14–24. There is **no custom icon font**; the only SVG sprite in
the repo (`assets/icons-sprite.svg`) is social/footer marks (GitHub, X, Bluesky,
Discord) — not UI icons. The UI kits load Lucide from CDN and render clean inline SVGs
(`ui_kits/*/Icon.jsx`), so icon usage stays faithful. Common glyphs: Ship, Home, Boxes,
Package, FileSpreadsheet, DollarSign, Receipt(Text), AlertTriangle, RefreshCw, Monitor,
User(Circle), Building2, LogOut, FilePlus2, Printer. **No emoji or unicode glyphs** are
used as icons in the real product.

> **Font note.** Syne, DM Sans and IBM Plex Mono load from Google Fonts (matching the
> product's own `@import`). No local font binaries were provided, so no `@font-face`
> files are bundled — the Google Fonts link in `tokens/typography.css` is the source of
> truth. If you want self-hosted webfonts, upload the `.woff2` files and we'll wire them.
